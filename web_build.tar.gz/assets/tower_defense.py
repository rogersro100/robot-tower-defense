import sys
import os
import subprocess


def _ensure_pygame():
    # Self-contained bootstrap: if pygame isn't installed for the
    # interpreter running this script, install it and continue.
    try:
        import pygame  # noqa: F401
        return
    except ImportError:
        pass
    # Some Android runtimes ship pygame_sdl2 (Ren'Py fork) instead
    try:
        import pygame_sdl2
        pygame_sdl2.import_as_pygame()
        return
    except ImportError:
        pass
    print("pygame not found - installing pygame...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pygame"])
    except (subprocess.CalledProcessError, FileNotFoundError):
        # pip may be missing entirely - bootstrap it first
        subprocess.check_call([sys.executable, "-m", "ensurepip", "--upgrade"])
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pygame"])


_ensure_pygame()

# Detect Android (Pydroid3 / python-for-android environments)
IS_ANDROID = (hasattr(sys, 'getandroidapilevel')
              or 'ANDROID_PRIVATE' in os.environ
              or 'PYDROID' in os.environ)

import pygame
import random
import math
import json
import textwrap

# Constants
GAME_TITLE = "Robot Tower Defense"
VERSION = "1.0.0"

CELL_SIZE = 50
GRID_WIDTH = 28
GRID_HEIGHT = 19
SCREEN_WIDTH = GRID_WIDTH * CELL_SIZE + 400
SCREEN_HEIGHT = GRID_HEIGHT * CELL_SIZE
FPS = 60

# Colors - Cyberpunk Theme
BLACK = (5, 5, 15)  # Deep blue-black
DARK_CYAN = (0, 30, 40)
NEON_GREEN = (0, 255, 128)
NEON_CYAN = (0, 255, 255)
NEON_PINK = (255, 0, 128)
NEON_PURPLE = (180, 0, 255)
NEON_ORANGE = (255, 128, 0)
NEON_BLUE = (0, 128, 255)
NEON_RED = (255, 50, 80)
DARK_GRAY = (20, 20, 35)
GRID_COLOR = (0, 50, 60)
WHITE = (255, 255, 255)
GRAY = (100, 100, 120)

# Legacy color mappings for compatibility
GREEN = NEON_GREEN
CYAN = NEON_CYAN
YELLOW = NEON_ORANGE
MAGENTA = NEON_PURPLE
RED = NEON_RED
ORANGE = NEON_ORANGE
LIGHT_GREEN = (100, 255, 150)
BLUE = NEON_BLUE

# Tower configurations
TOWER_TYPES = {
    'basic': {
        'name': 'Basic Bot',
        'cost': 50,
        'damage': 10,
        'range': 125,
        'fire_rate': 1000,
        'color': NEON_GREEN,
        'projectile_color': NEON_GREEN,
        'projectile_speed': 10,
        'ability': 'multishot',      # lvl3: 2 targets, lvl5: 3 targets
        'ability_name': 'MULTI-SHOT',
        'pros': 'Cheap, balanced all-rounder',
        'cons': 'Low damage vs tanks'
    },
    'sniper': {
        'name': 'Sniper Bot',
        'cost': 100,
        'damage': 30,
        'range': 250,
        'fire_rate': 2000,
        'color': NEON_CYAN,
        'projectile_color': NEON_CYAN,
        'projectile_speed': 18,
        'ability': 'aoe',            # lvl3: splash, lvl5: bigger splash
        'ability_name': 'SPLASH DMG',
        'aoe_base': 45,
        'pros': 'Huge range, heavy hits',
        'cons': 'Very slow fire rate'
    },
    'rapid': {
        'name': 'Rapid Bot',
        'cost': 150,
        'damage': 5,
        'range': 100,
        'fire_rate': 200,
        'color': NEON_ORANGE,
        'projectile_color': NEON_ORANGE,
        'projectile_speed': 12,
        'ability': 'continuous',     # lvl3/5: fire rate boost
        'ability_name': 'CONT. FIRE',
        'pros': 'Shreds swarms fast',
        'cons': 'Short range, weak hits'
    },
    'heavy': {
        'name': 'Heavy Bot',
        'cost': 200,
        'damage': 25,
        'range': 150,
        'fire_rate': 1500,
        'color': NEON_PURPLE,
        'projectile_color': NEON_PURPLE,
        'projectile_speed': 8,
        'ability': 'aoe',
        'ability_name': 'AOE BLAST',
        'aoe_base': 60,
        'pros': 'Big hits, AoE splash',
        'cons': 'Pricey and slow'
    },
    'tesla': {
        'name': 'Tesla Bot',
        'cost': 300,
        'damage': 35,
        'range': 140,
        'fire_rate': 900,
        'color': (255, 240, 90),  # Electric yellow
        'projectile_color': (200, 240, 255),
        'projectile_speed': 25,
        'ability': 'chain',          # chain lightning: 1 + level targets
        'ability_name': 'CHAIN LTNG',
        'pros': 'Chains to many foes',
        'cons': 'Expensive, mid range'
    },
    'frost': {
        'name': 'Frost Bot',
        'cost': 120,
        'damage': 6,
        'range': 130,
        'fire_rate': 800,
        'color': (140, 210, 255),   # Ice blue
        'projectile_color': (170, 230, 255),
        'projectile_speed': 14,
        'effect': {'type': 'slow', 'factor': 0.5, 'duration': 2000},
        'ability': 'multishot',      # lvl3: freezes 2 targets, lvl5: 3
        'ability_name': 'MULTI-CHILL',
        'pros': 'Slows enemies 50%',
        'cons': 'Very low damage'
    },
    'toxin': {
        'name': 'Toxin Bot',
        'cost': 175,
        'damage': 8,
        'range': 120,
        'fire_rate': 900,
        'color': (110, 255, 70),    # Toxic green
        'projectile_color': (140, 255, 90),
        'projectile_speed': 13,
        'effect': {'type': 'poison', 'dps': 7, 'duration': 3000},
        'ability': 'aoe',            # lvl3: poison cloud splash
        'ability_name': 'TOXIN CLOUD',
        'aoe_base': 50,
        'pros': 'Poison melts tanks',
        'cons': 'Weak upfront damage'
    },
    'void': {
        'name': 'Void Bot',
        'cost': 1000,
        'damage': 80,
        'range': 200,
        'fire_rate': 1200,
        'color': (110, 40, 200),    # Deep void purple
        'projectile_color': (170, 90, 255),
        'projectile_speed': 20,
        'effect': {'type': 'pull', 'cells': 3},  # gravity well yanks enemies back
        'ability': 'aoe',            # lvl3: event horizon splash
        'ability_name': 'EVENT HORIZON',
        'aoe_base': 80,
        'pros': 'Yanks foes back, huge dmg',
        'cons': 'Very expensive, slow'
    }
}

# Enemy configurations
ENEMY_TYPES = {
    'wrench': {
        'name': 'Wrench',
        'health': 30,
        'speed': 2.0,
        'reward': 10,
        'color': NEON_RED,
        'size': 18
    },
    'hammer': {
        'name': 'Hammer',
        'health': 60,
        'speed': 1.5,
        'reward': 20,
        'color': NEON_ORANGE,
        'size': 22
    },
    'screwdriver': {
        'name': 'Screwdriver',
        'health': 20,
        'speed': 3.0,
        'reward': 15,
        'color': NEON_GREEN,
        'size': 15
    },
    'drill': {
        'name': 'Drill',
        'health': 100,
        'speed': 1.0,
        'reward': 30,
        'color': NEON_PURPLE,
        'size': 25
    },
    'pliers': {
        'name': 'Pliers',
        'health': 45,
        'speed': 2.5,
        'reward': 18,
        'color': NEON_BLUE,
        'size': 20
    },
    'saw': {
        'name': 'Saw',
        'health': 70,
        'speed': 2.2,
        'reward': 22,
        'color': (200, 200, 210),  # Silver blade
        'size': 20
    },
    'tape': {
        'name': 'Tape Measure',
        'health': 15,
        'speed': 3.5,
        'reward': 12,
        'color': (255, 230, 60),  # Yellow casing
        'size': 14
    },
    'level': {
        'name': 'Level',
        'health': 120,
        'speed': 1.2,
        'reward': 35,
        'color': NEON_PINK,
        'size': 24
    },
    'crowbar': {
        'name': 'Crowbar',
        'health': 150,
        'speed': 1.8,
        'reward': 40,
        'color': (255, 80, 120),
        'size': 23
    },
    'stapler': {
        'name': 'Stapler (BOSS)',
        'health': 300,
        'speed': 0.8,
        'reward': 100,
        'color': (255, 215, 0),  # Gold
        'size': 30
    },
    'nail': {
        'name': 'Nail',
        'health': 8,
        'speed': 4.0,
        'reward': 5,
        'color': (170, 180, 200),  # Steel
        'size': 10
    },
    'cutter': {
        'name': 'Box Cutter',
        'health': 35,
        'speed': 3.2,
        'reward': 16,
        'color': (255, 160, 60),  # Orange casing
        'size': 16
    },
    'clamp': {
        'name': 'C-Clamp',
        'health': 90,
        'speed': 1.4,
        'reward': 28,
        'color': (140, 150, 170),  # Cast iron
        'size': 21
    },
    'axe': {
        'name': 'Axe',
        'health': 220,
        'speed': 1.1,
        'reward': 55,
        'color': (160, 90, 50),   # Wood + steel
        'size': 26
    }
}

# Difficulty presets - multipliers applied to enemies, plus starting resources
DIFFICULTIES = {
    'easy': {
        'name': 'EASY',
        'health_mult': 0.7,
        'speed_mult': 0.85,
        'count_mult': 0.8,
        'reward_mult': 1.2,
        'spawn_interval': 1100,
        'credits': 150,
        'lives': 30,
        'color': NEON_GREEN
    },
    'normal': {
        'name': 'NORMAL',
        'health_mult': 1.0,
        'speed_mult': 1.0,
        'count_mult': 1.0,
        'reward_mult': 1.0,
        'spawn_interval': 900,
        'credits': 100,
        'lives': 20,
        'color': NEON_CYAN
    },
    'hard': {
        'name': 'HARD',
        'health_mult': 1.6,
        'speed_mult': 1.15,
        'count_mult': 1.35,
        'reward_mult': 0.9,
        'spawn_interval': 700,
        'credits': 75,
        'lives': 15,
        'color': NEON_ORANGE
    },
    'insane': {
        'name': 'INSANE',
        'health_mult': 2.4,
        'speed_mult': 1.3,
        'count_mult': 1.7,
        'reward_mult': 0.8,
        'spawn_interval': 500,
        'credits': 50,
        'lives': 10,
        'color': NEON_RED
    }
}

class Tower:
    def __init__(self, grid_x, grid_y, tower_type):
        self.grid_x = grid_x
        self.grid_y = grid_y
        self.type = tower_type
        self.config = TOWER_TYPES[tower_type]
        self.level = 1
        self.last_fire = 0
        self.damage = self.config['damage']
        self.range = self.config['range']
        self.fire_rate = self.config['fire_rate']
        self.x = grid_x * CELL_SIZE + CELL_SIZE // 2
        self.y = grid_y * CELL_SIZE + CELL_SIZE // 2
        self.invested = self.config['cost']  # total credits spent on this tower
    
    def upgrade(self):
        cost = self.get_upgrade_cost()
        self.invested += cost
        self.level += 1
        self.damage = int(self.damage * 1.5)
        self.range = int(self.range * 1.1)
        self.fire_rate = max(60, int(self.fire_rate * 0.9))
        
        # Ability boosts kick in at level 3 and 5
        if self.config.get('ability') == 'continuous':
            if self.level == 3:
                self.fire_rate = max(50, int(self.fire_rate * 0.6))
            elif self.level == 5:
                self.fire_rate = max(35, int(self.fire_rate * 0.5))
    
    def get_upgrade_cost(self):
        return int(self.config['cost'] * self.level * 0.75)
    
    def get_sell_value(self):
        return int(self.invested * 0.7)
    
    def get_num_targets(self):
        ability = self.config.get('ability')
        if ability == 'multishot':
            if self.level >= 5:
                return 3
            if self.level >= 3:
                return 2
        elif ability == 'chain':
            # Tesla chain lightning - hits more enemies each level
            return min(1 + self.level, 6)
        return 1
    
    def get_aoe_radius(self):
        ability = self.config.get('ability')
        if ability == 'aoe':
            base = self.config.get('aoe_base', 40)
            if self.level >= 5:
                return int(base * 1.8)
            if self.level >= 3:
                return base
        return 0
    
    def get_ability_status(self):
        # Returns a short string describing the unlocked ability tier
        ability = self.config.get('ability')
        if ability == 'multishot' and self.level >= 3:
            return f"x{self.get_num_targets()} TARGETS"
        if ability == 'aoe' and self.level >= 3:
            return f"SPLASH {self.get_aoe_radius()}"
        if ability == 'continuous' and self.level >= 3:
            return "RAPID MODE"
        if ability == 'chain':
            return f"CHAIN x{self.get_num_targets()}"
        return None
    
    def can_fire(self, current_time):
        return current_time - self.last_fire >= self.fire_rate
    
    def fire(self, target):
        self.last_fire = pygame.time.get_ticks()
        effect = None
        base_effect = self.config.get('effect')
        if base_effect:
            effect = dict(base_effect)
            if effect['type'] == 'slow':
                # Chill lasts longer and bites harder with upgrades
                effect['duration'] = int(effect['duration'] * (1 + 0.25 * (self.level - 1)))
                if self.level >= 4:
                    effect['factor'] = max(0.3, effect['factor'] - 0.1)
            elif effect['type'] == 'poison':
                # Poison strength scales with level
                effect['dps'] = int(effect['dps'] * (1 + 0.5 * (self.level - 1)))
            elif effect['type'] == 'pull':
                # Gravity well reaches further back with upgrades
                effect['cells'] = effect['cells'] + (self.level - 1)
        return Projectile(self.x, self.y, target, self.damage,
                          self.config['projectile_color'],
                          self.config['projectile_speed'],
                          aoe_radius=self.get_aoe_radius(),
                          effect=effect)
    
    def draw(self, screen, selected):
        # Draw humanoid robot based on type
        self.draw_robot(screen)
        
        # Draw level indicator
        font = pygame.font.Font(None, 32)
        text = font.render(str(self.level), True, WHITE)
        text_rect = text.get_rect(center=(self.x, self.y - 30))
        screen.blit(text, text_rect)
        
        # Draw range circle if selected
        if selected:
            s = pygame.Surface((self.range * 2, self.range * 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (*self.config['color'], 50), (self.range, self.range), self.range)
            screen.blit(s, (self.x - self.range, self.y - self.range))
    
    def draw_robot(self, screen):
        color = self.config['color']
        x, y = int(self.x), int(self.y)
        
        # Animation time - each tower has a phase offset based on position
        t = pygame.time.get_ticks() / 1000.0 + (self.grid_x * 0.7 + self.grid_y * 1.3)
        
        # Bobbing hover animation
        bob = math.sin(t * 2.5) * 3
        y += int(bob)
        
        # Pulsing glow effect
        glow_alpha = int(40 + 25 * math.sin(t * 3))
        glow_surface = pygame.Surface((100, 100), pygame.SRCALPHA)
        pygame.draw.circle(glow_surface, (*color, glow_alpha), (50, 50), 30)
        screen.blit(glow_surface, (x - 50, y - 50))
        
        # Blinking eyes (blink every ~3s, closed for 0.15s)
        eyes_open = (t % 3.0) > 0.15
        
        # Arm sway
        sway = math.sin(t * 2.5) * 2
        
        if self.type == 'basic':
            # Small humanoid robot
            # Head
            pygame.draw.circle(screen, color, (x, y - 22), 10)
            pygame.draw.circle(screen, WHITE, (x, y - 22), 12, 2)
            # Antenna
            antenna_tip_x = x + int(math.sin(t * 4) * 3)
            pygame.draw.line(screen, color, (x, y - 30), (antenna_tip_x, y - 38), 2)
            pygame.draw.circle(screen, NEON_RED, (antenna_tip_x, y - 38), 2)
            # Eyes (blink)
            if eyes_open:
                pygame.draw.circle(screen, WHITE, (x - 4, y - 24), 3)
                pygame.draw.circle(screen, WHITE, (x + 4, y - 24), 3)
                pygame.draw.circle(screen, NEON_CYAN, (x - 4, y - 24), 1)
                pygame.draw.circle(screen, NEON_CYAN, (x + 4, y - 24), 1)
            else:
                pygame.draw.line(screen, WHITE, (x - 6, y - 24), (x - 2, y - 24), 1)
                pygame.draw.line(screen, WHITE, (x + 2, y - 24), (x + 6, y - 24), 1)
            # Body
            pygame.draw.rect(screen, color, (x - 10, y - 10, 20, 25))
            pygame.draw.rect(screen, WHITE, (x - 10, y - 10, 20, 25), 1)
            # Chest light (pulsing)
            light_alpha = int(150 + 105 * math.sin(t * 4))
            pygame.draw.circle(screen, (*NEON_CYAN,), (x, y + 2), 3)
            # Arms (swaying)
            pygame.draw.line(screen, color, (x - 10, y), (x - 18 - int(sway), y + 8), 5)
            pygame.draw.line(screen, color, (x + 10, y), (x + 18 + int(sway), y + 8), 5)
            # Legs
            pygame.draw.line(screen, color, (x - 5, y + 15), (x - 5, y + 28), 5)
            pygame.draw.line(screen, color, (x + 5, y + 15), (x + 5, y + 28), 5)
        
        elif self.type == 'sniper':
            # Tall humanoid robot with scope
            # Head
            pygame.draw.circle(screen, color, (x, y - 28), 12)
            pygame.draw.circle(screen, WHITE, (x, y - 28), 14, 2)
            # Scanning scope/visor (sweeps back and forth)
            scan = math.sin(t * 1.5) * 4
            pygame.draw.rect(screen, (100, 200, 255), (x - 10 + int(scan), y - 30, 20 - abs(int(scan)), 5))
            # Eye
            if eyes_open:
                pygame.draw.circle(screen, WHITE, (x, y - 28), 4)
            else:
                pygame.draw.line(screen, WHITE, (x - 4, y - 28), (x + 4, y - 28), 1)
            # Body (taller)
            pygame.draw.rect(screen, color, (x - 12, y - 14, 24, 35))
            pygame.draw.rect(screen, WHITE, (x - 12, y - 14, 24, 35), 1)
            # Chest core (pulsing)
            pygame.draw.circle(screen, NEON_CYAN, (x, y + 4), 4)
            # Arms (holding rifle, slight sway)
            pygame.draw.line(screen, color, (x - 12, y), (x - 22, y + 10 + int(sway)), 6)
            pygame.draw.line(screen, color, (x + 12, y), (x + 22, y + 10 + int(sway)), 6)
            # Rifle barrel with charging glow
            charge = int(100 + 155 * abs(math.sin(t * 2)))
            pygame.draw.line(screen, (100, 200, min(255, charge)), (x + 22, y + 10 + int(sway)), (x + 38, y + 10 + int(sway)), 5)
            pygame.draw.circle(screen, NEON_CYAN, (x + 38, y + 10 + int(sway)), 4)
            # Legs
            pygame.draw.line(screen, color, (x - 6, y + 21), (x - 6, y + 38), 6)
            pygame.draw.line(screen, color, (x + 6, y + 21), (x + 6, y + 38), 6)
        
        elif self.type == 'rapid':
            # Compact humanoid robot
            # Head
            pygame.draw.circle(screen, color, (x, y - 18), 9)
            pygame.draw.circle(screen, WHITE, (x, y - 18), 11, 2)
            # Eyes (blink)
            if eyes_open:
                pygame.draw.circle(screen, WHITE, (x - 4, y - 20), 3)
                pygame.draw.circle(screen, WHITE, (x + 4, y - 20), 3)
            else:
                pygame.draw.line(screen, WHITE, (x - 6, y - 20), (x - 2, y - 20), 1)
                pygame.draw.line(screen, WHITE, (x + 2, y - 20), (x + 6, y - 20), 1)
            # Body (compact)
            pygame.draw.rect(screen, color, (x - 12, y - 8, 24, 22))
            pygame.draw.rect(screen, WHITE, (x - 12, y - 8, 24, 22), 1)
            # Spinning barrel indicator
            spin = t * 8
            bx = x + int(math.cos(spin) * 3)
            pygame.draw.circle(screen, NEON_ORANGE, (bx, y + 4), 3)
            # Arms (gun barrels vibrating from rapid fire)
            jitter = int(math.sin(t * 12) * 1.5)
            pygame.draw.line(screen, color, (x - 12, y + 4), (x - 20, y + 4 + jitter), 5)
            pygame.draw.line(screen, color, (x + 12, y + 4), (x + 20, y + 4 - jitter), 5)
            pygame.draw.line(screen, (200, 200, 200), (x - 20, y + 4 + jitter), (x - 28, y + 4 + jitter), 4)
            pygame.draw.line(screen, (200, 200, 200), (x + 20, y + 4 - jitter), (x + 28, y + 4 - jitter), 4)
            # Muzzle flash tips (flickering)
            if math.sin(t * 10) > 0.3:
                pygame.draw.circle(screen, NEON_ORANGE, (x - 29, y + 4 + jitter), 3)
                pygame.draw.circle(screen, NEON_ORANGE, (x + 29, y + 4 - jitter), 3)
            # Legs
            pygame.draw.line(screen, color, (x - 5, y + 14), (x - 5, y + 26), 5)
            pygame.draw.line(screen, color, (x + 5, y + 14), (x + 5, y + 26), 5)
        
        elif self.type == 'heavy':
            # Large bulky humanoid robot
            # Head (large)
            pygame.draw.circle(screen, color, (x, y - 26), 15)
            pygame.draw.circle(screen, WHITE, (x, y - 26), 17, 2)
            # Visor (pulsing glow)
            visor_brightness = int(120 + 80 * math.sin(t * 3))
            pygame.draw.rect(screen, (visor_brightness, 50, 200), (x - 12, y - 30, 24, 8))
            # Eye
            if eyes_open:
                pygame.draw.circle(screen, WHITE, (x, y - 26), 5)
            else:
                pygame.draw.line(screen, WHITE, (x - 5, y - 26), (x + 5, y - 26), 2)
            # Body (bulky with armor plates)
            pygame.draw.rect(screen, color, (x - 18, y - 8, 36, 32))
            pygame.draw.rect(screen, WHITE, (x - 18, y - 8, 36, 32), 2)
            # Armor plates
            pygame.draw.rect(screen, (80, 40, 100), (x - 15, y - 5, 10, 12))
            pygame.draw.rect(screen, (80, 40, 100), (x + 5, y - 5, 10, 12))
            # Core reactor (pulsing)
            reactor = int(100 + 80 * math.sin(t * 4))
            pygame.draw.circle(screen, (reactor, 50, 200), (x, y + 8), 6)
            # Arms (heavy cannons, slight heave)
            heave = int(math.sin(t * 2) * 2)
            pygame.draw.line(screen, color, (x - 18, y + 6), (x - 28, y + 6 + heave), 10)
            pygame.draw.line(screen, color, (x + 18, y + 6), (x + 28, y + 6 + heave), 10)
            # Cannon barrels (charging glow)
            barrel_glow = int(150 + 105 * abs(math.sin(t * 2.5)))
            pygame.draw.line(screen, (barrel_glow, 50, 200), (x - 28, y + 6 + heave), (x - 40, y + 6 + heave), 8)
            pygame.draw.line(screen, (barrel_glow, 50, 200), (x + 28, y + 6 + heave), (x + 40, y + 6 + heave), 8)
            # Legs (thick)
            pygame.draw.line(screen, color, (x - 8, y + 24), (x - 8, y + 42), 10)
            pygame.draw.line(screen, color, (x + 8, y + 24), (x + 8, y + 42), 10)
        
        elif self.type == 'tesla':
            # Elite humanoid robot - floating coil rings + electric arcs
            # Head
            pygame.draw.circle(screen, color, (x, y - 30), 13)
            pygame.draw.circle(screen, WHITE, (x, y - 30), 15, 2)
            # Tesla coil antenna
            pygame.draw.line(screen, (200, 240, 255), (x, y - 43), (x, y - 55), 3)
            spark = abs(math.sin(t * 6)) 
            pygame.draw.circle(screen, (200, 240, 255), (x, y - 56), int(3 + spark * 3))
            # Eyes (visor style)
            if eyes_open:
                pygame.draw.rect(screen, (200, 240, 255), (x - 8, y - 33, 16, 5))
            else:
                pygame.draw.line(screen, WHITE, (x - 8, y - 30), (x + 8, y - 30), 1)
            # Body (sleek, armored)
            pygame.draw.rect(screen, color, (x - 14, y - 16, 28, 36))
            pygame.draw.rect(screen, WHITE, (x - 14, y - 16, 28, 36), 1)
            # Core coil (pulsing)
            coil_glow = int(150 + 105 * math.sin(t * 5))
            pygame.draw.circle(screen, (200, 240, min(255, coil_glow + 100)), (x, y + 2), 6)
            pygame.draw.circle(screen, WHITE, (x, y + 2), 8, 1)
            # Floating rings (orbiting coil discs)
            for ring_i in range(2):
                ring_y = y - 4 + ring_i * 16 + int(math.sin(t * 3 + ring_i) * 2)
                ring_w = 44 - ring_i * 8
                pygame.draw.ellipse(screen, (200, 240, 255),
                                    (x - ring_w // 2, ring_y - 4, ring_w, 8), 2)
            # Electric arc sparks between rings (random flicker)
            if int(t * 10) % 3 == 0:
                pygame.draw.line(screen, WHITE,
                                 (x - 18, y - 4), (x - 14, y + 12), 2)
                pygame.draw.line(screen, (200, 240, 255),
                                 (x + 16, y + 20), (x + 20, y + 6), 2)
            # Arms (capacitor gauntlets)
            gaunt = int(math.sin(t * 4) * 3)
            pygame.draw.line(screen, color, (x - 14, y - 6), (x - 26, y + 2 + gaunt), 7)
            pygame.draw.line(screen, color, (x + 14, y - 6), (x + 26, y + 2 - gaunt), 7)
            pygame.draw.circle(screen, (200, 240, 255), (x - 28, y + 2 + gaunt), 6)
            pygame.draw.circle(screen, (200, 240, 255), (x + 28, y + 2 - gaunt), 6)
            # Legs (armored)
            pygame.draw.line(screen, color, (x - 7, y + 20), (x - 7, y + 38), 8)
            pygame.draw.line(screen, color, (x + 7, y + 20), (x + 7, y + 38), 8)
        
        elif self.type == 'frost':
            # Slim humanoid with cryo emitters
            # Head
            pygame.draw.circle(screen, color, (x, y - 24), 11)
            pygame.draw.circle(screen, WHITE, (x, y - 24), 13, 2)
            # Cryo crest (ice spike)
            pygame.draw.polygon(screen, (200, 240, 255), [(x - 4, y - 33), (x + 4, y - 33), (x, y - 46)])
            # Eyes (cold glow, blink)
            if eyes_open:
                pygame.draw.circle(screen, (220, 245, 255), (x - 4, y - 26), 3)
                pygame.draw.circle(screen, (220, 245, 255), (x + 4, y - 26), 3)
            else:
                pygame.draw.line(screen, WHITE, (x - 6, y - 26), (x - 2, y - 26), 1)
                pygame.draw.line(screen, WHITE, (x + 2, y - 26), (x + 6, y - 26), 1)
            # Body (slim, frosted)
            pygame.draw.rect(screen, color, (x - 11, y - 12, 22, 28))
            pygame.draw.rect(screen, WHITE, (x - 11, y - 12, 22, 28), 1)
            # Frost core (pulsing ice glow)
            frost_glow = int(150 + 105 * math.sin(t * 3.5))
            pygame.draw.circle(screen, (frost_glow, 230, 255), (x, y + 1), 5)
            # Cryo arms (emitters with mist shimmer)
            mist = int(math.sin(t * 5) * 3)
            pygame.draw.line(screen, color, (x - 11, y - 2), (x - 21, y + 6 + mist), 5)
            pygame.draw.line(screen, color, (x + 11, y - 2), (x + 21, y + 6 - mist), 5)
            pygame.draw.circle(screen, (200, 240, 255), (x - 23, y + 6 + mist), 5)
            pygame.draw.circle(screen, (200, 240, 255), (x + 23, y + 6 - mist), 5)
            # Snowflake shimmer around emitters
            if math.sin(t * 6) > 0:
                pygame.draw.circle(screen, WHITE, (x - 26, y + 2 + mist), 2)
                pygame.draw.circle(screen, WHITE, (x + 26, y + 10 - mist), 2)
            # Legs
            pygame.draw.line(screen, color, (x - 5, y + 16), (x - 5, y + 33), 6)
            pygame.draw.line(screen, color, (x + 5, y + 16), (x + 5, y + 33), 6)
        
        elif self.type == 'toxin':
            # Hazmat-style humanoid with toxin canisters
            # Head (hooded visor look)
            pygame.draw.circle(screen, color, (x, y - 22), 12)
            pygame.draw.circle(screen, (60, 90, 40), (x, y - 22), 14, 2)
            # Visor (green glow)
            visor = int(120 + 80 * math.sin(t * 2.5))
            pygame.draw.rect(screen, (visor, 255, visor // 2), (x - 8, y - 26, 16, 6))
            # Body (bulky hazmat suit)
            pygame.draw.rect(screen, color, (x - 14, y - 10, 28, 30))
            pygame.draw.rect(screen, (60, 90, 40), (x - 14, y - 10, 28, 30), 2)
            # Toxin tank on back (bubbling)
            pygame.draw.rect(screen, (80, 180, 60), (x + 10, y - 16, 8, 22))
            bubble = int((t * 20) % 14)
            pygame.draw.circle(screen, (180, 255, 120), (x + 14, y + 4 - bubble), 2)
            # Chest vent (pulsing toxic glow)
            vent = int(150 + 105 * math.sin(t * 4))
            pygame.draw.circle(screen, (vent // 2, 255, vent // 2), (x, y + 2), 4)
            # Arms (sprayer nozzles)
            sway2 = math.sin(t * 3) * 2
            pygame.draw.line(screen, color, (x - 14, y), (x - 24, y + 8 + int(sway2)), 6)
            pygame.draw.line(screen, color, (x + 14, y), (x + 24, y + 8 - int(sway2)), 6)
            # Nozzle tips (dripping toxin)
            pygame.draw.circle(screen, (140, 255, 90), (x - 26, y + 10 + int(sway2)), 4)
            pygame.draw.circle(screen, (140, 255, 90), (x + 26, y + 10 - int(sway2)), 4)
            if math.sin(t * 8) > 0.6:
                pygame.draw.circle(screen, (140, 255, 90), (x - 26, y + 16 + int(sway2)), 2)
            # Legs (thick hazmat boots)
            pygame.draw.line(screen, color, (x - 7, y + 20), (x - 7, y + 36), 8)
            pygame.draw.line(screen, color, (x + 7, y + 20), (x + 7, y + 36), 8)
        
        elif self.type == 'void':
            # Massive dark mech - black hole core + orbiting shards
            # Head
            pygame.draw.circle(screen, color, (x, y - 30), 14)
            pygame.draw.circle(screen, (200, 160, 255), (x, y - 30), 16, 2)
            # Orbiting void shards around head
            for i in range(4):
                a = t * 1.5 + i * math.pi / 2
                hx = x + int(math.cos(a) * 20)
                hy = y - 30 + int(math.sin(a) * 7)
                pygame.draw.circle(screen, (170, 90, 255), (hx, hy), 2)
            # Visor
            if eyes_open:
                pygame.draw.rect(screen, (200, 140, 255), (x - 9, y - 33, 18, 5))
            else:
                pygame.draw.line(screen, WHITE, (x - 9, y - 30), (x + 9, y - 30), 1)
            # Body (large, dark plating)
            pygame.draw.rect(screen, color, (x - 16, y - 16, 32, 36))
            pygame.draw.rect(screen, (200, 160, 255), (x - 16, y - 16, 32, 36), 1)
            # Black hole core (dark disc + pulsing accretion ring)
            pygame.draw.circle(screen, (8, 0, 18), (x, y + 2), 9)
            ring_r = 13 + int(math.sin(t * 4) * 3)
            pygame.draw.circle(screen, (170, 90, 255), (x, y + 2), ring_r, 2)
            # Arms (void claws, reach outward)
            reach = int(math.sin(t * 3) * 4)
            pygame.draw.line(screen, color, (x - 16, y - 6), (x - 30 - reach, y + 4), 8)
            pygame.draw.line(screen, color, (x + 16, y - 6), (x + 30 + reach, y + 4), 8)
            pygame.draw.circle(screen, (30, 8, 55), (x - 32 - reach, y + 4), 6)
            pygame.draw.circle(screen, (30, 8, 55), (x + 32 + reach, y + 4), 6)
            pygame.draw.circle(screen, (170, 90, 255), (x - 32 - reach, y + 4), 6, 1)
            pygame.draw.circle(screen, (170, 90, 255), (x + 32 + reach, y + 4), 6, 1)
            # Legs (heavy)
            pygame.draw.line(screen, color, (x - 8, y + 20), (x - 8, y + 40), 9)
            pygame.draw.line(screen, color, (x + 8, y + 20), (x + 8, y + 40), 9)

class Projectile:
    def __init__(self, x, y, target, damage, color, speed, aoe_radius=0, effect=None):
        self.x = x
        self.y = y
        self.target = target
        self.damage = damage
        self.color = color
        self.speed = speed
        self.aoe_radius = aoe_radius
        self.effect = effect      # status effect dict (slow/poison) or None
        self.active = True
        self.hit = False          # set when the projectile lands
        self.hit_x = 0
        self.hit_y = 0
    
    def update(self):
        if not self.target or not self.target.active:
            self.active = False
            return
        
        dx = self.target.x - self.x
        dy = self.target.y - self.y
        distance = math.sqrt(dx * dx + dy * dy)
        
        if distance < self.speed:
            self.target.take_damage(self.damage)
            self.target.apply_effect(self.effect)
            self.hit = True
            self.hit_x = self.target.x
            self.hit_y = self.target.y
            self.active = False
        else:
            self.x += (dx / distance) * self.speed
            self.y += (dy / distance) * self.speed
    
    def draw(self, screen):
        # Draw neon laser line with glow
        if self.target and self.target.active:
            # Outer glow
            pygame.draw.line(screen, (*self.color, 100), (self.x, self.y), 
                           (self.target.x, self.target.y), 7)
            # Inner bright line
            pygame.draw.line(screen, (255, 255, 255), (self.x, self.y), 
                           (self.target.x, self.target.y), 2)
            # Color line
            pygame.draw.line(screen, self.color, (self.x, self.y), 
                           (self.target.x, self.target.y), 4)
        
        # Draw projectile head with glow
        pygame.draw.circle(screen, (*self.color, 100), (int(self.x), int(self.y)), 8)
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), 4)
        pygame.draw.circle(screen, (255, 255, 255), (int(self.x), int(self.y)), 2)

class Enemy:
    def __init__(self, enemy_type, path, health_mult=1.0, speed_mult=1.0, reward_mult=1.0):
        self.type = enemy_type
        self.config = ENEMY_TYPES[enemy_type]
        self.health = int(self.config['health'] * health_mult)
        self.max_health = self.health
        self.speed = self.config['speed'] * speed_mult
        self.reward = int(self.config['reward'] * reward_mult)
        self.path = path
        self.path_index = 0
        self.active = True
        
        if path and len(path) > 0:
            # Start from the first point in the path
            self.x = path[0][0] * CELL_SIZE + CELL_SIZE // 2
            self.y = path[0][1] * CELL_SIZE + CELL_SIZE // 2
        else:
            # Fallback if no path
            self.x = CELL_SIZE + CELL_SIZE // 2
            self.y = (GRID_HEIGHT // 2) * CELL_SIZE + CELL_SIZE // 2
        
        # Status effects
        self.slow_until = 0        # tick timestamp when slow expires
        self.slow_factor = 1.0     # speed multiplier while slowed
        self.poison_until = 0      # tick timestamp when poison expires
        self.poison_dps = 0        # damage per second while poisoned
        self.poison_acc = 0.0      # accumulated fractional poison damage
    
    def update(self):
        if not self.path or len(self.path) == 0:
            self.active = False
            return 'reached_end'
        
        now = pygame.time.get_ticks()
        
        # Poison damage over time (ticked per update call so game speed scales it)
        if self.poison_until > now and self.poison_dps > 0:
            self.poison_acc += self.poison_dps / FPS
            if self.poison_acc >= 1:
                dmg = int(self.poison_acc)
                self.poison_acc -= dmg
                self.take_damage(dmg)
                if not self.active:
                    return None
        
        if self.path_index >= len(self.path) - 1:
            self.active = False
            return 'reached_end'
        
        target = self.path[self.path_index + 1]
        target_x = target[0] * CELL_SIZE + CELL_SIZE // 2
        target_y = target[1] * CELL_SIZE + CELL_SIZE // 2
        
        dx = target_x - self.x
        dy = target_y - self.y
        distance = math.sqrt(dx * dx + dy * dy)
        
        # Effective speed (slowed while frost effect is active)
        speed = self.speed
        if now < self.slow_until:
            speed *= self.slow_factor
        
        # Move towards target
        if distance < speed:
            self.path_index += 1
        else:
            self.x += (dx / distance) * speed
            self.y += (dy / distance) * speed
        
        return None
    
    def apply_effect(self, effect):
        if not effect or not self.active:
            return
        now = pygame.time.get_ticks()
        if effect['type'] == 'slow':
            # Stronger slow wins; always refresh duration
            if self.slow_until <= now or effect['factor'] < self.slow_factor:
                self.slow_factor = effect['factor']
            self.slow_until = now + effect['duration']
        elif effect['type'] == 'poison':
            # Refresh duration; keep the stronger poison tick
            if self.poison_until <= now:
                self.poison_dps = effect['dps']
            else:
                self.poison_dps = max(self.poison_dps, effect['dps'])
            self.poison_until = now + effect['duration']
        elif effect['type'] == 'pull':
            # Gravity well - yank the enemy back along the path
            if self.path:
                self.path_index = max(0, self.path_index - effect['cells'])
                cell = self.path[self.path_index]
                self.x = cell[0] * CELL_SIZE + CELL_SIZE // 2
                self.y = cell[1] * CELL_SIZE + CELL_SIZE // 2
    
    def take_damage(self, damage):
        self.health -= damage
        if self.health <= 0:
            self.active = False
            return self.reward
        return 0
    
    def draw(self, screen):
        # Draw tool shape based on type
        self.draw_tool(screen)
        
        # Draw health bar
        bar_width = 30
        bar_height = 4
        health_percent = self.health / self.max_health
        
        bar_x = self.x - bar_width // 2
        bar_y = self.y - 25
        
        pygame.draw.rect(screen, GRAY, (bar_x, bar_y, bar_width, bar_height))
        
        health_color = GREEN if health_percent > 0.5 else (YELLOW if health_percent > 0.25 else RED)
        pygame.draw.rect(screen, health_color, (bar_x, bar_y, bar_width * health_percent, bar_height))
        
        # Status effect indicators
        now = pygame.time.get_ticks()
        ex, ey = int(self.x), int(self.y)
        if now < self.slow_until:
            # Frost aura - icy ring + sparkle
            t = now / 1000.0
            r = self.config['size'] // 2 + 7 + int(math.sin(t * 6) * 2)
            pygame.draw.circle(screen, (150, 220, 255), (ex, ey), r, 2)
            pygame.draw.circle(screen, WHITE, (ex - r + 3, ey - 4), 2)
            pygame.draw.circle(screen, WHITE, (ex + r - 3, ey + 4), 2)
        if now < self.poison_until:
            # Poison bubbles rising off the body
            for i in range(3):
                rise = (now // 150 + i * 5) % 14
                pygame.draw.circle(screen, (130, 255, 80),
                                   (ex - 8 + i * 8, ey - 8 - rise), 2)
    
    def draw_tool(self, screen):
        color = self.config['color']
        x, y = int(self.x), int(self.y)
        
        if self.type == 'wrench':
            # Draw wrench - handle + C-shaped head
            # Handle
            pygame.draw.rect(screen, color, (x - 3, y - 15, 6, 20))
            # Head (C-shape)
            pygame.draw.arc(screen, color, (x - 10, y - 25, 20, 20), 0, 3.14, 3)
            pygame.draw.arc(screen, color, (x - 10, y - 25, 20, 20), 3.14, 6.28, 3)
            # Jaw
            pygame.draw.line(screen, color, (x - 10, y - 15), (x - 10, y - 5), 3)
            pygame.draw.line(screen, color, (x + 10, y - 15), (x + 10, y - 5), 3)
        
        elif self.type == 'hammer':
            # Draw hammer - handle + head
            # Handle
            pygame.draw.rect(screen, color, (x - 3, y + 5, 6, 20))
            # Head
            pygame.draw.rect(screen, color, (x - 12, y - 8, 24, 12))
            # Claw
            pygame.draw.polygon(screen, color, [(x - 12, y - 8), (x - 8, y - 15), (x - 6, y - 8)])
        
        elif self.type == 'screwdriver':
            # Draw screwdriver - handle + shaft
            # Handle
            pygame.draw.rect(screen, color, (x - 4, y + 5, 8, 15))
            # Shaft
            pygame.draw.rect(screen, (200, 200, 200), (x - 2, y - 12, 4, 17))
            # Tip
            pygame.draw.polygon(screen, (200, 200, 200), [(x - 2, y - 12), (x + 2, y - 12), (x, y - 18)])
        
        elif self.type == 'drill':
            # Draw drill - body + bit
            # Body
            pygame.draw.rect(screen, color, (x - 6, y - 8, 12, 20))
            # Motor housing
            pygame.draw.rect(screen, (100, 100, 100), (x - 8, y - 5, 16, 10))
            # Bit
            pygame.draw.polygon(screen, (150, 150, 150), [(x - 2, y + 12), (x + 2, y + 12), (x, y + 22)])
        
        elif self.type == 'pliers':
            # Draw pliers - two handles + pivot + jaws
            # Handles
            pygame.draw.line(screen, color, (x - 8, y + 12), (x - 4, y - 8), 4)
            pygame.draw.line(screen, color, (x + 8, y + 12), (x + 4, y - 8), 4)
            # Pivot
            pygame.draw.circle(screen, (150, 150, 150), (x, y - 8), 5)
            # Jaws
            pygame.draw.line(screen, color, (x - 4, y - 8), (x - 8, y - 18), 3)
            pygame.draw.line(screen, color, (x + 4, y - 8), (x + 8, y - 18), 3)
        
        elif self.type == 'saw':
            # Draw circular saw blade - disc + teeth + center bolt
            t = pygame.time.get_ticks() / 1000.0
            angle = (t * 8) % (math.pi * 2)  # spinning blade
            # Teeth (8 small triangles around the rim)
            for i in range(8):
                a = angle + i * math.pi / 4
                tx = x + int(math.cos(a) * 14)
                ty = y + int(math.sin(a) * 14)
                pygame.draw.circle(screen, color, (tx, ty), 3)
            # Blade disc
            pygame.draw.circle(screen, color, (x, y), 11)
            pygame.draw.circle(screen, (120, 120, 130), (x, y), 11, 2)
            # Center bolt
            pygame.draw.circle(screen, (80, 80, 90), (x, y), 4)
        
        elif self.type == 'tape':
            # Draw tape measure - case + extended tape strip
            # Case (rounded square)
            pygame.draw.rect(screen, color, (x - 8, y - 6, 16, 14))
            pygame.draw.rect(screen, (60, 60, 60), (x - 8, y - 6, 16, 14), 2)
            # Belt clip
            pygame.draw.rect(screen, (60, 60, 60), (x - 4, y - 10, 8, 4))
            # Extended tape (flickers in/out as it moves)
            t = pygame.time.get_ticks() / 1000.0
            tape_len = int(10 + 6 * math.sin(t * 6))
            pygame.draw.line(screen, (230, 230, 230), (x + 8, y), (x + 8 + tape_len, y), 4)
            pygame.draw.line(screen, NEON_RED, (x + 8 + tape_len - 2, y), (x + 8 + tape_len, y), 4)
        
        elif self.type == 'level':
            # Draw level - long bar + bubble vials
            # Bar body
            pygame.draw.rect(screen, color, (x - 20, y - 6, 40, 12))
            pygame.draw.rect(screen, (150, 60, 150), (x - 20, y - 6, 40, 12), 2)
            # Bubble vial (center) - animated bubble slides
            t = pygame.time.get_ticks() / 1000.0
            pygame.draw.rect(screen, (180, 255, 200), (x - 7, y - 3, 14, 6))
            bubble_x = x + int(math.sin(t * 2) * 3)
            pygame.draw.circle(screen, (100, 255, 150), (bubble_x, y), 3)
            # End caps
            pygame.draw.rect(screen, (120, 40, 120), (x - 22, y - 7, 4, 14))
            pygame.draw.rect(screen, (120, 40, 120), (x + 18, y - 7, 4, 14))
        
        elif self.type == 'crowbar':
            # Draw crowbar - curved bar + claw end
            # Main shaft (diagonal)
            pygame.draw.line(screen, color, (x - 10, y + 12), (x + 8, y - 10), 6)
            # Curved claw head
            pygame.draw.arc(screen, color, (x + 2, y - 22, 16, 16), 3.5, 6.0, 5)
            # Claw tip (flattened)
            pygame.draw.line(screen, color, (x + 14, y - 18), (x + 18, y - 14), 4)
            # Worn grip marks
            pygame.draw.line(screen, (150, 40, 80), (x - 6, y + 7), (x - 2, y + 4), 2)
            pygame.draw.line(screen, (150, 40, 80), (x - 2, y + 3), (x + 2, y), 2)
        
        elif self.type == 'nail':
            # Draw nail - thin steel spike with flat head
            # Head
            pygame.draw.line(screen, color, (x - 5, y - 14), (x + 5, y - 14), 4)
            # Shaft
            pygame.draw.line(screen, color, (x, y - 12), (x, y + 12), 3)
            # Point
            pygame.draw.polygon(screen, color, [(x - 2, y + 12), (x + 2, y + 12), (x, y + 17)])
            # Shine glint
            pygame.draw.line(screen, WHITE, (x - 1, y - 10), (x - 1, y + 4), 1)
        
        elif self.type == 'cutter':
            # Draw box cutter - body + sliding blade
            # Body (utility handle)
            pygame.draw.rect(screen, color, (x - 6, y - 4, 22, 10))
            pygame.draw.rect(screen, (120, 70, 30), (x - 6, y - 4, 22, 10), 1)
            # Slider button
            pygame.draw.rect(screen, (60, 60, 70), (x + 2, y - 7, 6, 4))
            # Blade (segmented, juts out)
            pygame.draw.polygon(screen, (210, 220, 230),
                                [(x - 6, y - 3), (x - 18, y + 1), (x - 6, y + 5)])
            # Blade score lines
            pygame.draw.line(screen, (150, 155, 165), (x - 9, y - 1), (x - 12, y + 3), 1)
        
        elif self.type == 'clamp':
            # Draw C-clamp - C frame + screw bar + handle
            # C frame (two arcs forming the C)
            pygame.draw.arc(screen, color, (x - 14, y - 18, 24, 30), 1.2, 5.1, 5)
            # Top jaw
            pygame.draw.line(screen, color, (x - 12, y - 12), (x - 2, y - 12), 5)
            # Screw bar (below bottom jaw, animated turn)
            t = pygame.time.get_ticks() / 1000.0
            screw = int(math.sin(t * 3) * 2)
            pygame.draw.line(screen, (110, 115, 130), (x - 10, y + 10), (x - 10, y + 20), 4)
            # T-handle on screw
            pygame.draw.line(screen, color, (x - 16, y + 20 + screw), (x - 4, y + 20 + screw), 4)
            # Pressure pad on screw top
            pygame.draw.circle(screen, (110, 115, 130), (x - 10, y + 9), 3)
        
        elif self.type == 'axe':
            # Draw axe - wooden handle + steel head
            # Handle (diagonal wood)
            pygame.draw.line(screen, (150, 90, 40), (x - 8, y + 16), (x + 10, y - 14), 5)
            # Head (steel wedge on top end)
            pygame.draw.polygon(screen, color,
                                [(x + 2, y - 20), (x + 18, y - 22), (x + 20, y - 8), (x + 6, y - 10)])
            # Blade edge (bright)
            pygame.draw.line(screen, (220, 230, 240), (x + 18, y - 22), (x + 20, y - 8), 3)
            # Grip wrap
            pygame.draw.line(screen, (90, 50, 20), (x - 6, y + 12), (x - 3, y + 16), 4)
        
        elif self.type == 'stapler':
            # Draw stapler (boss) - body + hinge + base
            # Base
            pygame.draw.rect(screen, color, (x - 15, y + 5, 30, 10))
            # Body
            pygame.draw.rect(screen, color, (x - 12, y - 12, 24, 17))
            # Hinge
            pygame.draw.rect(screen, (100, 100, 100), (x - 10, y - 5, 20, 5))
            # Staple exit
            pygame.draw.rect(screen, (50, 50, 50), (x - 3, y + 12, 6, 3))
            # Boss indicator - crown
            pygame.draw.polygon(screen, (255, 255, 0), [(x - 8, y - 18), (x, y - 25), (x + 8, y - 18)])

class Game:
    def __init__(self):
        pygame.init()
        # SCALED renders at the logical 1800x950 and stretches to fit the
        # real display (also rescales touch/mouse coords). FULLSCREEN on
        # Android; resizable window on desktop; plain canvas on web -
        # the page template owns sizing and flag bits are unsupported.
        if sys.platform == 'emscripten':
            flags = 0
        elif IS_ANDROID:
            flags = getattr(pygame, 'SCALED', 0) | pygame.FULLSCREEN
        else:
            flags = getattr(pygame, 'SCALED', 0) | pygame.RESIZABLE
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), flags)
        pygame.display.set_caption(f"{GAME_TITLE} v{VERSION}")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 32)
        self.small_font = pygame.font.Font(None, 24)
        self.title_font = pygame.font.Font(None, 48)
        self.difficulty = 'normal'
        self.min_path_pct = 45  # % of interior cells the path must cover
        self.game_speed = 1     # update ticks per frame (1x/2x/3x)
        
        # Player identity + persistent per-name high scores
        self.player_name = "PLAYER"
        self.editing_name = False
        self.high_scores = self.load_high_scores()
        self.new_record = 0
        
        self.reset_game()
        
        # Prompt the user for their pilot name on launch
        self.player_name = ""
        self.editing_name = True
        self.message = "ENTER PILOT NAME // type & press ENTER"
    
    def reset_game(self):
        # Record the previous run's score before wiping state
        if getattr(self, 'wave', 1) > 1 or getattr(self, 'game_over', False):
            self.record_score()
        self.new_record = 0
        diff = DIFFICULTIES[self.difficulty]
        self.credits = diff['credits']
        self.lives = diff['lives']
        self.wave = 1
        self.enemies = []
        self.towers = []
        self.projectiles = []
        self.effects = []
        self.path = []
        self.selected_tower = None
        self.selected_tower_type = None
        self.hover_tower_type = None
        self.wave_in_progress = False
        self.game_over = False
        self.message = "SYSTEM READY // Select unit to deploy"
        self.wave_enemies = []
        self.enemy_spawn_timer = 0
        self.enemy_spawn_index = 0
        self.start_pos = None
        self.end_pos = None
        
        # Generate starfield background (stars drift across the grid)
        self.stars = []
        for _ in range(400):
            self.stars.append({
                'x': random.uniform(0, GRID_WIDTH * CELL_SIZE),
                'y': random.uniform(0, SCREEN_HEIGHT),
                'size': random.choice([1, 1, 1, 2, 2, 2, 3]),
                'speed': random.uniform(0.5, 2.0),     # twinkle speed
                'phase': random.uniform(0, math.pi * 2),
                'vx': random.uniform(-0.8, 0.8),       # drift velocity
                'vy': random.uniform(-0.4, 0.4)
            })
        # A few bright colored feature stars for depth
        for _ in range(30):
            self.stars.append({
                'x': random.uniform(0, GRID_WIDTH * CELL_SIZE),
                'y': random.uniform(0, SCREEN_HEIGHT),
                'size': random.choice([2, 3, 3, 4]),
                'speed': random.uniform(0.3, 1.2),
                'phase': random.uniform(0, math.pi * 2),
                'vx': random.uniform(-0.5, 0.5),
                'vy': random.uniform(-0.25, 0.25),
                'tint': random.choice([(255, 200, 150), (150, 220, 255), (255, 150, 220), (200, 255, 200)])
            })
        
        # Translucent cell tints so the moving starfield shows through the grid
        self.path_cell_overlay = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
        self.path_cell_overlay.fill((10, 25, 40, 80))
        self.empty_cell_overlay = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
        self.empty_cell_overlay.fill((0, 0, 10, 45))
        
        # Nebula clouds
        self.nebulas = []
        for _ in range(5):
            self.nebulas.append({
                'x': random.randint(0, GRID_WIDTH * CELL_SIZE),
                'y': random.randint(0, SCREEN_HEIGHT),
                'radius': random.randint(80, 200),
                'color': random.choice([(60, 0, 90), (0, 40, 80), (70, 0, 50), (20, 50, 80)]),
                'drift': random.uniform(-0.15, 0.15)
            })
        
        self.generate_maze()
    
    def generate_maze(self):
        # Initialize grid - everything is open deep space (placeable)
        self.grid = []
        for y in range(GRID_HEIGHT):
            row = []
            for x in range(GRID_WIDTH):
                row.append({'type': 'empty', 'tower': None})
            self.grid.append(row)
        
        # Random orientation: left→right, top→bottom, or bottom→top.
        # S/E live ON the border wall. The entry must sit near a corner
        # edge so the serpentine can sweep the full map under the
        # 1-cell gap rule (mid-grid starts can't cover both sides).
        start_edge, exit_edge = random.choice(
            [('left', 'right'), ('top', 'bottom'), ('bottom', 'top')])
        
        if start_edge == 'left':
            self.start_pos = (0, random.choice([1, GRID_HEIGHT - 2]))
        elif start_edge == 'top':
            self.start_pos = (random.choice([1, GRID_WIDTH - 2]), 0)
        else:  # bottom
            self.start_pos = (random.choice([1, GRID_WIDTH - 2]), GRID_HEIGHT - 1)
        
        if exit_edge == 'right':
            self.end_pos = (GRID_WIDTH - 1, random.randint(2, GRID_HEIGHT - 3))
        elif exit_edge == 'bottom':
            self.end_pos = (random.randint(2, GRID_WIDTH - 3), GRID_HEIGHT - 1)
        else:  # top
            self.end_pos = (random.randint(2, GRID_WIDTH - 3), 0)
        
        # Snake box: the exit edge's approach strip is reserved so the
        # final leg is always carved through untouched territory.
        box_x_min, box_x_max = 1, GRID_WIDTH - 2
        box_y_min, box_y_max = 1, GRID_HEIGHT - 2
        if exit_edge == 'right':
            box_x_max = GRID_WIDTH - 5   # reserve x >= GW-4
        elif exit_edge == 'top':
            box_y_min = 4                # reserve y <= 3
        elif exit_edge == 'bottom':
            box_y_max = GRID_HEIGHT - 5  # reserve y >= GH-4
        
        # Interior start cell (one step inside the border gate)
        sx, sy = self.start_pos
        interior_start = (
            min(max(sx, box_x_min), box_x_max),
            min(max(sy, box_y_min), box_y_max)
        )
        
        # With the 1-cell gap rule, a serpentine covers ~55% of cells max
        interior_cells = (GRID_WIDTH - 2) * (GRID_HEIGHT - 2)
        min_path_length = int(interior_cells * self.min_path_pct / 100)
        
        box = (box_x_min, box_x_max, box_y_min, box_y_max)
        # Freeform walks produce the most irregular layouts - most games
        # use them; they trade shorter paths and extra retries for
        # uniqueness. Serpentine generators remain for variety and as
        # the reliable fallback whenever a walk can't finish.
        self.path = None
        if random.random() < 0.85:
            # Freestyle doesn't need the corner-start constraint the
            # serpentine sweep does (it must cover both sides of the
            # entry) - allow any position along the entry edge.
            if start_edge == 'left':
                self.start_pos = (0, random.randint(1, GRID_HEIGHT - 2))
            elif start_edge == 'top':
                self.start_pos = (random.randint(1, GRID_WIDTH - 2), 0)
            else:
                self.start_pos = (random.randint(1, GRID_WIDTH - 2),
                                  GRID_HEIGHT - 1)
            sx, sy = self.start_pos
            interior_start = (
                min(max(sx, box_x_min), box_x_max),
                min(max(sy, box_y_min), box_y_max)
            )
            self.path = self.generate_path_freestyle(
                interior_start, self.start_pos, self.end_pos,
                exit_edge, box, min_path_length)
        if self.path is None:
            if exit_edge == 'right':
                self.path = self.generate_path(
                    interior_start, self.start_pos, self.end_pos,
                    exit_edge, box, min_path_length
                )
            else:
                # Vertical serpentine for top/bottom exits
                self.path = self.generate_path_vertical(
                    interior_start, self.start_pos, self.end_pos,
                    exit_edge, box, min_path_length
                )
        
        # Validate: path must be contiguous and never revisit a square
        valid = len(set(self.path)) == len(self.path)
        if valid:
            valid = all(
                abs(self.path[i][0] - self.path[i-1][0]) +
                abs(self.path[i][1] - self.path[i-1][1]) == 1
                for i in range(1, len(self.path))
            )
        if not valid:
            # Regenerate once more - extremely rare, keeps map legal
            if exit_edge == 'right':
                self.path = self.serpentine_fallback(
                    interior_start, self.start_pos, self.end_pos, box)
            else:
                self.path = self.serpentine_fallback_vertical(
                    interior_start, self.start_pos, self.end_pos,
                    exit_edge, box)
        
        # Mark path cells in the grid (includes border S/E cells)
        for (px, py) in self.path:
            self.grid[py][px]['type'] = 'path'
    
    def generate_path(self, interior_start, start_border, end_border,
                      exit_edge, box, min_length):
        # Band-filling serpentine. Sweeps full-width horizontal lanes,
        # transitioning 2-3 rows at each end so lanes keep a 1-cell gap.
        # Once min_length is met it stops only at the exit-side boundary,
        # so the approach through the reserved strip is always clean.
        box_x_min, box_x_max, box_y_min, box_y_max = box
        
        def clear_of(nx, ny, from_cell, visited):
            for dx, dy in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
                ax, ay = nx + dx, ny + dy
                if (ax, ay) != from_cell and (ax, ay) in visited:
                    return False
            return True
        
        for attempt in range(300):
            path = [interior_start]
            visited = {interior_start}
            cx, cy = interior_start
            
            # First lane heads toward the exit side
            xdir = 1 if exit_edge == 'right' else -1
            # Sweep vertically AWAY from the start edge
            vdir = 1 if cy <= (box_y_min + box_y_max) // 2 else -1
            
            # Staggered lanes: ~35% of lanes stop 2-9 cells short of the
            # far edge so turns land mid-map - organic, unique layouts
            def pick_stop(direction):
                if len(path) < min_length and random.random() < 0.35:
                    short = random.randint(2, 9)
                    if direction > 0:
                        return box_x_max - short
                    return box_x_min + short
                return None
            
            lane_stop = pick_stop(xdir)
            ended_at_boundary = False
            max_steps = GRID_WIDTH * GRID_HEIGHT * 3
            steps = 0

            # Hybrid layouts: this attempt may switch to vertical lanes
            # mid-path, producing two-zone maps instead of a pure snake.
            # Early attempts prefer hybrids so they win the race to first
            # valid path, but pure snakes still appear for variety.
            phase = 'h'
            ydir = vdir
            mixed = attempt < 8 or random.random() < 0.55
            switched = False

            def try_notch(axis):
                # Carve a 1-cell-deep tooth: dip perpendicular 1, run
                # parallel 2, come back - leaves a 1-cell hole in the
                # lane. Every cell still obeys the no-touch rule.
                if axis == 'h':
                    if not (box_x_min <= cx + 2 * xdir <= box_x_max):
                        return False
                    # Hybrid candidates dip back into swept territory so
                    # the comb band stays virgin (self-rejects on step-2
                    # spacing, i.e. effectively no notches for them).
                    d = (-vdir if mixed and not switched
                         else random.choice([1, -1]))
                    cells = [(cx, cy + d), (cx + xdir, cy + d),
                             (cx + 2 * xdir, cy + d), (cx + 2 * xdir, cy)]
                else:
                    if not (box_y_min <= cy + 2 * ydir <= box_y_max):
                        return False
                    d = random.choice([1, -1])
                    cells = [(cx + d, cy), (cx + d, cy + ydir),
                             (cx + d, cy + 2 * ydir), (cx, cy + 2 * ydir)]
                tx, ty = cx, cy
                for (nnx, nny) in cells:
                    if not (box_x_min <= nnx <= box_x_max
                            and box_y_min <= nny <= box_y_max):
                        return False
                    if (nnx, nny) in visited:
                        return False
                    if not clear_of(nnx, nny, (tx, ty), visited):
                        return False
                    tx, ty = nnx, nny
                for c in cells:
                    path.append(c)
                    visited.add(c)
                return True

            while steps < max_steps:
                steps += 1

                if phase == 'h':
                    # Mid-lane hybrid turn: comb-fill the band below with
                    # vertical lanes, sweeping to the right edge.
                    if mixed and not switched:
                        rows_left = ((box_y_max - cy) if vdir > 0
                                     else (cy - box_y_min))
                        cols_right = box_x_max - cx
                        if (rows_left >= 4 and cols_right >= 6
                                and len(path)
                                    + (cols_right // 2 + 1) * (rows_left - 1)
                                    + cols_right // 2 >= min_length
                                and (cx, cy + vdir) not in visited
                                and clear_of(cx, cy + vdir,
                                             (cx, cy), visited)
                                and random.random() < 0.12):
                            band_lo = cy + 1 if vdir > 0 else box_y_min
                            band_hi = box_y_max if vdir > 0 else cy - 1
                            if all((bx, by) not in visited
                                   for by in range(band_lo, band_hi + 1)
                                   for bx in range(cx, box_x_max + 1)):
                                phase = 'v'
                                ydir = vdir
                                switched = True
                                continue

                    # 1. Run horizontally to the box edge (or stagger point)
                    nx = cx + xdir
                    hit_stop = lane_stop is not None and cx == lane_stop
                    if (not hit_stop and box_x_min <= nx <= box_x_max
                            and (nx, cy) not in visited
                            and clear_of(nx, cy, (cx, cy), visited)):
                        if (len(path) < min_length
                                and random.random() < 0.08
                                and try_notch('h')):
                            cx += 2 * xdir
                            continue
                        cx = nx
                        path.append((cx, cy))
                        visited.add((cx, cy))
                        continue

                    # Reached a boundary. If long enough AND on the exit
                    # side, stop - the reserve approach is always clean.
                    at_exit_edge = (
                        (exit_edge == 'right' and cx == box_x_max) or
                        (exit_edge == 'left' and cx == box_x_min)
                    )
                    if at_exit_edge and len(path) >= min_length:
                        ended_at_boundary = True
                        break

                    # Hybrid switch at a lane end: comb-fill the band
                    # below with vertical lanes sweeping right. Needs
                    # band rows, columns of room, enough fill capacity
                    # to still reach min_length, and a virgin band.
                    rows_left = ((box_y_max - cy) if vdir > 0
                                 else (cy - box_y_min))
                    cols_right = box_x_max - cx
                    # The comb needs virgin territory: notches and
                    # backtracking transitions sprinkle cells into the
                    # band otherwise, and ragged blockers jam it.
                    band_lo = cy + 1 if vdir > 0 else box_y_min
                    band_hi = box_y_max if vdir > 0 else cy - 1
                    band_clean = all(
                        (bx, by) not in visited
                        for by in range(band_lo, band_hi + 1)
                        for bx in range(cx, box_x_max + 1))
                    if (mixed and not switched and rows_left >= 4
                            and cols_right >= 5 and band_clean
                            and len(path)
                                + (cols_right // 2 + 1) * (rows_left - 1)
                                + cols_right // 2 >= min_length
                            and (cx, cy + vdir) not in visited
                            and clear_of(cx, cy + vdir, (cx, cy), visited)
                            and random.random() < 0.7):
                        phase = 'v'
                        ydir = vdir
                        switched = True
                        continue

                    # 2. Vertical transition: step 2-3 rows (sometimes 4-5
                    # for wide open bands), prefer vdir. Hybrid attempts
                    # must pack at maximum density (step 2) or the comb
                    # region can't bank enough cells to reach min_length.
                    if mixed and not switched:
                        steps_opts = [2]
                    else:
                        steps_opts = [2, 3]
                        if random.random() < 0.25:
                            steps_opts += [4, 5]
                    preferred = [vdir * s for s in steps_opts]
                    random.shuffle(preferred)
                    options = preferred + [-vdir * s for s in (2, 3)]
                    moved = False
                    for dy in options:
                        sign = 1 if dy > 0 else -1
                        clear = True
                        for i in range(1, abs(dy) + 1):
                            check_y = cy + sign * i
                            if not (box_y_min <= check_y <= box_y_max):
                                clear = False
                                break
                            if (cx, check_y) in visited:
                                clear = False
                                break
                            if not clear_of(cx, check_y, (cx, check_y - sign), visited):
                                clear = False
                                break
                        if clear:
                            for _ in range(abs(dy)):
                                cy += sign
                                path.append((cx, cy))
                                visited.add((cx, cy))
                            xdir = -xdir
                            lane_stop = pick_stop(xdir)
                            moved = True
                            break
                    if not moved:
                        break  # genuinely stuck
                else:
                    # Phase 'v': vertical comb lanes sweeping columns to
                    # the right edge - only reachable after the hybrid
                    # switch. Forward-only steps keep the fill
                    # deterministic so it can't self-trap.
                    ny = cy + ydir
                    if (box_y_min <= ny <= box_y_max
                            and (cx, ny) not in visited
                            and clear_of(cx, ny, (cx, cy), visited)):
                        cy = ny
                        path.append((cx, cy))
                        visited.add((cx, cy))
                        continue

                    if cx >= box_x_max - 1 and len(path) >= min_length:
                        ended_at_boundary = True
                        break

                    clear = True
                    for i in (1, 2):
                        check_x = cx + i
                        if not (box_x_min <= check_x <= box_x_max):
                            clear = False
                            break
                        if (check_x, cy) in visited:
                            clear = False
                            break
                        if not clear_of(check_x, cy, (check_x - 1, cy), visited):
                            clear = False
                            break
                    if not clear:
                        break
                    for _ in range(2):
                        cx += 1
                        path.append((cx, cy))
                        visited.add((cx, cy))
                    ydir = -ydir

            if not ended_at_boundary or len(path) < min_length:
                continue  # wrong end or too short - retry

            # Approach legs through the reserved strip (right exit)
            legs = []
            leg1 = [(x, cy) for x in range(cx + 1, GRID_WIDTH - 2)]
            step_y = 1 if end_border[1] > cy else -1
            leg2 = [(GRID_WIDTH - 3, yy)
                    for yy in range(cy + step_y, end_border[1] + step_y, step_y)]
            leg3 = [(GRID_WIDTH - 2, end_border[1]), end_border]
            legs = [leg1, leg2, leg3]
            
            # Verify every leg cell is clean before committing
            ok = True
            tx, ty = cx, cy
            for leg in legs:
                for (nx, ny) in leg:
                    if (nx, ny) in visited or not clear_of(nx, ny, (tx, ty), visited):
                        ok = False
                        break
                    tx, ty = nx, ny
                if not ok:
                    break
            if not ok:
                continue
            
            for leg in legs:
                for cell in leg:
                    path.append(cell)
                    visited.add(cell)
            
            return [start_border] + path
        
        # Fallback: full-coverage serpentine (systematic, never direct)
        return self.serpentine_fallback(interior_start, start_border,
                                        end_border, box)
    
    def serpentine_fallback(self, interior_start, start_border, end_border, box):
        # Deterministic serpentine: sweeps every other row away from the
        # start edge. Start is always at an edge row so no stub is needed.
        box_x_min, box_x_max, box_y_min, box_y_max = box
        path = [start_border, interior_start]
        cx, cy = interior_start
        
        xdir = 1
        # Sweep away from the start edge
        vdir = 1 if cy <= (box_y_min + box_y_max) // 2 else -1
        while True:
            # Run horizontally to the box edge
            while box_x_min <= cx + xdir <= box_x_max:
                cx += xdir
                path.append((cx, cy))
            # Step 2 rows in vdir; stop if we'd leave the box
            ny = cy + 2 * vdir
            if not (box_y_min <= ny <= box_y_max):
                break
            for _ in range(2):
                cy += vdir
                path.append((cx, cy))
            xdir = -xdir
        
        # Approach to exit through the reserve (right exit)
        while cx < GRID_WIDTH - 3:
            cx += 1
            path.append((cx, cy))
        step_y = 1 if end_border[1] > cy else -1
        while cy != end_border[1]:
            cy += step_y
            path.append((cx, cy))
        while cx != end_border[0]:
            cx += 1
            path.append((cx, cy))
        return path
    
    def generate_path_vertical(self, interior_start, start_border, end_border,
                               exit_edge, box, min_length):
        # Vertical band-filling serpentine (transpose of horizontal).
        # Lanes run down columns; transitions step 2-3 columns. Only
        # stops at the exit-facing boundary so the reserve approach
        # is always clean. exit_edge is 'top' or 'bottom'.
        box_x_min, box_x_max, box_y_min, box_y_max = box
        
        def clear_of(nx, ny, from_cell, visited):
            for dx, dy in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
                ax, ay = nx + dx, ny + dy
                if (ax, ay) != from_cell and (ax, ay) in visited:
                    return False
            return True
        
        for attempt in range(300):
            path = [interior_start]
            visited = {interior_start}
            cx, cy = interior_start
            
            # First lane heads toward the exit edge
            ydir = 1 if exit_edge == 'bottom' else -1
            # Sweep horizontally away from the start corner
            hdir = 1 if cx <= (box_x_min + box_x_max) // 2 else -1
            
            # Staggered lanes: ~35% stop 2-9 cells short of the far edge
            def pick_stop(direction):
                if len(path) < min_length and random.random() < 0.35:
                    short = random.randint(2, 9)
                    if direction > 0:
                        return box_y_max - short
                    return box_y_min + short
                return None
            
            lane_stop = pick_stop(ydir)
            ended_at_boundary = False
            max_steps = GRID_WIDTH * GRID_HEIGHT * 3
            steps = 0

            # Hybrid layouts: this attempt may switch to horizontal lanes
            # mid-path, producing two-zone maps instead of a pure snake.
            phase = 'v'
            xdir = hdir
            mixed = attempt < 8 or random.random() < 0.55
            switched = False

            def try_notch(axis):
                # Carve a 1-cell-deep tooth off the lane (see the
                # horizontal generator for the geometry).
                if axis == 'h':
                    if not (box_x_min <= cx + 2 * xdir <= box_x_max):
                        return False
                    d = random.choice([1, -1])
                    cells = [(cx, cy + d), (cx + xdir, cy + d),
                             (cx + 2 * xdir, cy + d), (cx + 2 * xdir, cy)]
                else:
                    if not (box_y_min <= cy + 2 * ydir <= box_y_max):
                        return False
                    # Hybrid candidates dip back toward swept columns so
                    # the comb strip stays virgin (see the h-generator).
                    d = (-hdir if mixed and not switched
                         else random.choice([1, -1]))
                    cells = [(cx + d, cy), (cx + d, cy + ydir),
                             (cx + d, cy + 2 * ydir), (cx, cy + 2 * ydir)]
                tx, ty = cx, cy
                for (nnx, nny) in cells:
                    if not (box_x_min <= nnx <= box_x_max
                            and box_y_min <= nny <= box_y_max):
                        return False
                    if (nnx, nny) in visited:
                        return False
                    if not clear_of(nnx, nny, (tx, ty), visited):
                        return False
                    tx, ty = nnx, nny
                for c in cells:
                    path.append(c)
                    visited.add(c)
                return True

            while steps < max_steps:
                steps += 1

                if phase == 'v':
                    # Mid-lane hybrid turn: comb-fill the column strip
                    # with horizontal lanes marching toward the exit edge.
                    if mixed and not switched:
                        rows_exit = ((box_y_max - cy)
                                     if exit_edge == 'bottom'
                                     else (cy - box_y_min))
                        cols_left = ((box_x_max - cx) if hdir > 0
                                     else (cx - box_x_min))
                        if (rows_exit >= 5 and cols_left >= 5
                                and len(path)
                                    + (rows_exit // 2 + 1) * (cols_left - 1)
                                    + rows_exit // 2 >= min_length
                                and (cx + hdir, cy) not in visited
                                and clear_of(cx + hdir, cy,
                                             (cx, cy), visited)
                                and random.random() < 0.12):
                            strip_lo, strip_hi = (
                                (cx + 1, box_x_max) if hdir > 0
                                else (box_x_min, cx - 1))
                            if all((bx, by) not in visited
                                   for bx in range(strip_lo, strip_hi + 1)
                                   for by in range(box_y_min,
                                                   box_y_max + 1)):
                                phase = 'h'
                                xdir = hdir
                                switched = True
                                continue

                    # 1. Run vertically to the box edge (or stagger point)
                    ny = cy + ydir
                    hit_stop = lane_stop is not None and cy == lane_stop
                    if (not hit_stop and box_y_min <= ny <= box_y_max
                            and (cx, ny) not in visited
                            and clear_of(cx, ny, (cx, cy), visited)):
                        if (len(path) < min_length
                                and random.random() < 0.08
                                and try_notch('v')):
                            cy += 2 * ydir
                            continue
                        cy = ny
                        path.append((cx, cy))
                        visited.add((cx, cy))
                        continue

                    # Reached a boundary. If long enough AND on the exit
                    # side, stop - the reserve approach is always clean.
                    at_exit_edge = (
                        (exit_edge == 'bottom' and cy == box_y_max) or
                        (exit_edge == 'top' and cy == box_y_min)
                    )
                    if at_exit_edge and len(path) >= min_length:
                        ended_at_boundary = True
                        break

                    # Hybrid switch: dive into a deterministic horizontal
                    # comb-fill inside the remaining COLUMN strip (the
                    # vertical lanes span full height, so untouched space
                    # is columns beyond this one). Lanes march rows
                    # toward the exit. Needs 5+ cols of strip, 6+ rows to
                    # march, and enough fill capacity for min_length.
                    rows_exit = ((box_y_max - cy) if exit_edge == 'bottom'
                                 else (cy - box_y_min))
                    cols_left = ((box_x_max - cx) if hdir > 0
                                 else (cx - box_x_min))
                    # Comb needs a virgin strip - notch teeth poke cells
                    # into adjacent columns and jam horizontal lanes.
                    strip_lo, strip_hi = ((cx + 1, box_x_max) if hdir > 0
                                          else (box_x_min, cx - 1))
                    strip_clean = all(
                        (bx, by) not in visited
                        for bx in range(strip_lo, strip_hi + 1)
                        for by in range(box_y_min, box_y_max + 1))
                    if (mixed and not switched and rows_exit >= 5
                            and cols_left >= 5 and strip_clean
                            and len(path)
                                + (rows_exit // 2) * cols_left
                                + rows_exit // 2 >= min_length
                            and (cx + hdir, cy) not in visited
                            and clear_of(cx + hdir, cy, (cx, cy), visited)
                            and random.random() < 0.7):
                        phase = 'h'
                        xdir = hdir
                        switched = True
                        continue

                    # 2. Horizontal transition: step 2-3 cols (sometimes
                    # 4-5 for wide bands), prefer hdir. Hybrid attempts
                    # pack at max density (step 2) so the comb region can
                    # still reach min_length.
                    if mixed and not switched:
                        steps_opts = [2]
                    else:
                        steps_opts = [2, 3]
                        if random.random() < 0.25:
                            steps_opts += [4, 5]
                    preferred = [hdir * s for s in steps_opts]
                    random.shuffle(preferred)
                    options = preferred + [-hdir * s for s in (2, 3)]
                    moved = False
                    for dx in options:
                        sign = 1 if dx > 0 else -1
                        clear = True
                        for i in range(1, abs(dx) + 1):
                            check_x = cx + sign * i
                            if not (box_x_min <= check_x <= box_x_max):
                                clear = False
                                break
                            if (check_x, cy) in visited:
                                clear = False
                                break
                            if not clear_of(check_x, cy, (check_x - sign, cy), visited):
                                clear = False
                                break
                        if clear:
                            for _ in range(abs(dx)):
                                cx += sign
                                path.append((cx, cy))
                                visited.add((cx, cy))
                            ydir = -ydir
                            lane_stop = pick_stop(ydir)
                            moved = True
                            break
                    if not moved:
                        break
                else:
                    # Phase 'h': horizontal lanes sweeping rows toward
                    # the exit edge - only after the hybrid switch.
                    nx = cx + xdir
                    if (box_x_min <= nx <= box_x_max
                            and (nx, cy) not in visited
                            and clear_of(nx, cy, (cx, cy), visited)):
                        cx = nx
                        path.append((cx, cy))
                        visited.add((cx, cy))
                        continue

                    near_exit_edge = (
                        (exit_edge == 'bottom' and cy >= box_y_max - 1) or
                        (exit_edge == 'top' and cy <= box_y_min + 1)
                    )
                    if near_exit_edge and len(path) >= min_length:
                        ended_at_boundary = True
                        break

                    # Row transition toward the exit edge, step 2-3
                    # (sometimes 4), forward-only comb fill, flip xdir.
                    vdir_exit = 1 if exit_edge == 'bottom' else -1
                    options = [vdir_exit * 2]
                    moved = False
                    for dy in options:
                        sign = 1 if dy > 0 else -1
                        clear = True
                        for i in range(1, abs(dy) + 1):
                            check_y = cy + sign * i
                            if not (box_y_min <= check_y <= box_y_max):
                                clear = False
                                break
                            if (cx, check_y) in visited:
                                clear = False
                                break
                            if not clear_of(cx, check_y, (cx, check_y - sign), visited):
                                clear = False
                                break
                        if clear:
                            for _ in range(abs(dy)):
                                cy += sign
                                path.append((cx, cy))
                                visited.add((cx, cy))
                            xdir = -xdir
                            moved = True
                            break
                    if not moved:
                        break
            
            if not ended_at_boundary or len(path) < min_length:
                continue
            
            # Approach legs through the reserved strip. The corridor row
            # must sit 2 rows off the last lane row so leg2 has an empty
            # margin row on each side (no adjacency violations).
            if exit_edge == 'bottom':
                corridor_y = GRID_HEIGHT - 3   # margin row = GH-4
                leg1 = [(cx, yy) for yy in range(cy + 1, corridor_y + 1)]
                step_x = 1 if end_border[0] > cx else -1
                leg2 = [(xx, corridor_y) for xx in range(cx + step_x, end_border[0] + step_x, step_x)]
                leg3 = [(end_border[0], corridor_y + 1), end_border]
                legs = [leg1, leg2, leg3]
            else:  # top
                corridor_y = 2                 # margin row = 3
                leg1 = [(cx, yy) for yy in range(cy - 1, corridor_y - 1, -1)]
                step_x = 1 if end_border[0] > cx else -1
                leg2 = [(xx, corridor_y) for xx in range(cx + step_x, end_border[0] + step_x, step_x)]
                leg3 = [(end_border[0], 1), end_border]
                legs = [leg1, leg2, leg3]
            
            ok = True
            tx, ty = cx, cy
            for leg in legs:
                for (nx, ny) in leg:
                    if (nx, ny) in visited or not clear_of(nx, ny, (tx, ty), visited):
                        ok = False
                        break
                    tx, ty = nx, ny
                if not ok:
                    break
            if not ok:
                continue
            
            for leg in legs:
                for cell in leg:
                    path.append(cell)
                    visited.add(cell)
            
            return [start_border] + path
        
        return self.serpentine_fallback_vertical(
            interior_start, start_border, end_border, exit_edge, box)
    
    def serpentine_fallback_vertical(self, interior_start, start_border,
                                     end_border, exit_edge, box):
        # Deterministic vertical serpentine - sweep every other column.
        box_x_min, box_x_max, box_y_min, box_y_max = box
        path = [start_border, interior_start]
        cx, cy = interior_start
        
        ydir = 1 if exit_edge == 'bottom' else -1
        hdir = 1 if cx <= (box_x_min + box_x_max) // 2 else -1
        while True:
            # Run vertically to the box edge
            while box_y_min <= cy + ydir <= box_y_max:
                cy += ydir
                path.append((cx, cy))
            # Step 2 columns in hdir; stop if we'd leave the box
            nx = cx + 2 * hdir
            if not (box_x_min <= nx <= box_x_max):
                break
            for _ in range(2):
                cx += hdir
                path.append((cx, cy))
            ydir = -ydir
        
        # Approach to exit through the reserve (corridor has 1-row margin)
        if exit_edge == 'bottom':
            corridor_y = GRID_HEIGHT - 3
            while cy < corridor_y:
                cy += 1
                path.append((cx, cy))
            step_x = 1 if end_border[0] > cx else -1
            while cx != end_border[0]:
                cx += step_x
                path.append((cx, cy))
            while cy != end_border[1]:
                cy += 1
                path.append((cx, cy))
        else:  # top
            corridor_y = 2
            while cy > corridor_y:
                cy -= 1
                path.append((cx, cy))
            step_x = 1 if end_border[0] > cx else -1
            while cx != end_border[0]:
                cx += step_x
                path.append((cx, cy))
            while cy != end_border[1]:
                cy -= 1
                path.append((cx, cy))
        return path

    def generate_path_freestyle(self, interior_start, start_border,
                                end_border, exit_edge, box, min_length):
        """Randomized depth-first induced path - no lane structure at
        all, just an organic self-avoiding walk obeying the same
        1-cell-gap rule. The most irregular layouts in the game. Trades
        minimum length and generation time for uniqueness: the target
        is a randomized fraction of min_length and each attempt burns a
        bounded backtracking budget before giving up."""
        box_x_min, box_x_max, box_y_min, box_y_max = box

        def clear_of(nx, ny, from_cell, visited):
            for dx, dy in [(0, -1), (0, 1), (-1, 0), (1, 0)]:
                a = (nx + dx, ny + dy)
                if a != from_cell and a in visited:
                    return False
            return True

        # The walk must finish flush against the box edge on the exit
        # side so the approach leg only crosses the (always virgin)
        # reserved strip.
        if exit_edge == 'right':
            ex, ey = 1, 0
            in_end_zone = lambda x, y: x >= box_x_max
        elif exit_edge == 'bottom':
            ex, ey = 0, 1
            in_end_zone = lambda x, y: y >= box_y_max
        else:  # top
            ex, ey = 0, -1
            in_end_zone = lambda x, y: y <= box_y_min

        for attempt in range(40):
            # Per-attempt personality: drift strength toward the exit
            # edge plus an optional secondary pull toward one
            # perpendicular side, so routes hug different corners.
            drift = random.uniform(0.3, 0.65)
            pull = random.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
            pull_p = random.uniform(0.0, 0.3)

            def fresh_dirs():
                d4 = [(1, 0), (-1, 0), (0, 1), (0, -1)]
                random.shuffle(d4)
                if pull != (ex, ey) and random.random() < pull_p:
                    d4.remove(pull)
                    d4.insert(0, pull)
                if random.random() < drift:
                    d4.remove((ex, ey))
                    d4.insert(0, (ex, ey))
                return d4

            target = max(90, int(min_length * random.uniform(0.55, 0.95)))
            path = [interior_start]
            visited = {interior_start}
            cand = [fresh_dirs()]
            done = False
            budget = 60000
            while path and budget > 0:
                budget -= 1
                cx, cy = path[-1]
                nxt = None
                dirs = cand[-1]
                while dirs:
                    dx, dy = dirs.pop()
                    nx, ny = cx + dx, cy + dy
                    if (box_x_min <= nx <= box_x_max
                            and box_y_min <= ny <= box_y_max
                            and (nx, ny) not in visited
                            and clear_of(nx, ny, (cx, cy), visited)):
                        nxt = (nx, ny)
                        break
                if nxt is not None:
                    path.append(nxt)
                    visited.add(nxt)
                    cand.append(fresh_dirs())
                    if len(path) >= target and in_end_zone(*nxt):
                        done = True
                        break
                else:
                    cand.pop()
                    visited.remove(path.pop())
            if not done:
                continue

            # Approach legs through the reserved strip (same geometry
            # as the serpentine generators).
            cx, cy = path[-1]
            if exit_edge == 'right':
                leg1 = [(x, cy) for x in range(cx + 1, GRID_WIDTH - 2)]
                step_y = 1 if end_border[1] > cy else -1
                leg2 = [(GRID_WIDTH - 3, yy) for yy in
                        range(cy + step_y, end_border[1] + step_y, step_y)]
                leg3 = [(GRID_WIDTH - 2, end_border[1]), end_border]
            elif exit_edge == 'bottom':
                corridor_y = GRID_HEIGHT - 3
                leg1 = [(cx, yy) for yy in range(cy + 1, corridor_y + 1)]
                step_x = 1 if end_border[0] > cx else -1
                leg2 = [(xx, corridor_y) for xx in
                        range(cx + step_x, end_border[0] + step_x, step_x)]
                leg3 = [(end_border[0], corridor_y + 1), end_border]
            else:  # top
                corridor_y = 2
                leg1 = [(cx, yy) for yy in range(cy - 1, corridor_y - 1, -1)]
                step_x = 1 if end_border[0] > cx else -1
                leg2 = [(xx, corridor_y) for xx in
                        range(cx + step_x, end_border[0] + step_x, step_x)]
                leg3 = [(end_border[0], 1), end_border]
            ok = True
            tx, ty = cx, cy
            for leg in (leg1, leg2, leg3):
                for (nx, ny) in leg:
                    if (nx, ny) in visited \
                            or not clear_of(nx, ny, (tx, ty), visited):
                        ok = False
                        break
                    tx, ty = nx, ny
                if not ok:
                    break
            if not ok:
                continue
            for leg in (leg1, leg2, leg3):
                for c in leg:
                    path.append(c)
            return [start_border] + path
        return None

    def get_wave_config(self, wave):
        diff = DIFFICULTIES[self.difficulty]
        base_enemies = int((5 + wave * 5) * diff['count_mult'])  # more enemies per wave
        interval = diff['spawn_interval']
        
        enemy_types = ['wrench']
        
        if wave >= 2:
            enemy_types.append('screwdriver')
            enemy_types.append('nail')      # fast swarm unit
        if wave >= 3:
            enemy_types.append('hammer')
            enemy_types.append('tape')      # fast, fragile
        if wave >= 4:
            enemy_types.append('pliers')
            enemy_types.append('saw')       # medium all-rounder
        if wave >= 5:
            enemy_types.append('cutter')    # fast striker
            enemy_types.append('clamp')     # sturdy
        if wave >= 6:
            enemy_types.append('drill')
            enemy_types.append('level')     # tanky
        if wave >= 8:
            enemy_types.append('crowbar')   # heavy armor
        if wave >= 9:
            enemy_types.append('axe')       # heavy tank
        
        enemies = []
        for i in range(base_enemies):
            enemy_type = random.choice(enemy_types)
            # Spawn interval shrinks faster each wave
            wave_interval = max(280, interval - wave * 20)
            enemies.append({'type': enemy_type, 'delay': i * wave_interval})
        
        # Add boss (stapler) every 5 waves starting from wave 5
        if wave >= 5 and wave % 5 == 0:
            boss_delay = (base_enemies // 2) * wave_interval + 500
            enemies.append({'type': 'stapler', 'delay': boss_delay})
            # Extra bosses on harder difficulties
            if self.difficulty in ('hard', 'insane'):
                enemies.append({'type': 'stapler', 'delay': boss_delay + wave_interval * 3})
        
        return enemies
    
    def start_wave(self):
        if self.wave_in_progress or self.game_over:
            return
        
        self.wave_in_progress = True
        self.wave_enemies = self.get_wave_config(self.wave)
        self.enemy_spawn_index = 0
        self.enemy_spawn_timer = pygame.time.get_ticks()
        self.message = f"WAVE {self.wave} INITIATED // Engaging hostiles"
    
    def spawn_enemies(self):
        if not self.wave_in_progress:
            return
        
        current_time = pygame.time.get_ticks()
        
        while (self.enemy_spawn_index < len(self.wave_enemies) and
               current_time - self.enemy_spawn_timer >= self.wave_enemies[self.enemy_spawn_index]['delay']):
            enemy_data = self.wave_enemies[self.enemy_spawn_index]
            
            # Only spawn if we have a valid path
            if self.path and len(self.path) > 1:
                diff = DIFFICULTIES[self.difficulty]
                # Per-wave scaling: +15% health and +5% speed each wave
                wave_health = 1.0 + (self.wave - 1) * 0.15
                wave_speed = 1.0 + (self.wave - 1) * 0.05
                enemy = Enemy(enemy_data['type'], self.path,
                              health_mult=diff['health_mult'] * wave_health,
                              speed_mult=diff['speed_mult'] * wave_speed,
                              reward_mult=diff['reward_mult'])
                self.enemies.append(enemy)
                if enemy_data['type'] == 'stapler':
                    self.message = "WARNING: BOSS DETECTED // STAPLER PROTOCOL"
            
            self.enemy_spawn_index += 1
    
    def check_wave_complete(self):
        if self.wave_in_progress and len(self.enemies) == 0 and self.enemy_spawn_index >= len(self.wave_enemies):
            self.wave_in_progress = False
            self.wave += 1
            bonus = 50 + self.wave * 10
            self.credits += bonus
            self.message = f"WAVE {self.wave - 1} CLEARED // Bonus: {bonus}c"
    
    def _save_path(self, filename):
        # Save files live next to the script (works on Android where cwd
        # may differ from the script location)
        try:
            base = os.path.dirname(os.path.abspath(__file__))
            return os.path.join(base, filename)
        except Exception:
            return filename
    
    def load_high_scores(self, filename="high_scores.json"):
        filename = self._save_path(filename)
        if not os.path.exists(filename):
            return {}
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            if isinstance(data, dict):
                return {str(k): int(v) for k, v in data.items()}
        except Exception:
            pass
        return {}
    
    def save_high_scores(self, filename="high_scores.json"):
        try:
            with open(self._save_path(filename), 'w') as f:
                json.dump(self.high_scores, f)
        except Exception:
            pass
    
    def record_score(self):
        # Score = highest wave reached; kept per player name
        score = getattr(self, 'wave', 0)
        if score > self.high_scores.get(self.player_name, 0):
            self.high_scores[self.player_name] = score
            self.save_high_scores()
            self.new_record = score
    
    def save_map(self, filename="saved_map.json"):
        filename = self._save_path(filename)
        # Save the path layout, start/end positions, and grid to a file
        data = {
            'start_pos': list(self.start_pos),
            'end_pos': list(self.end_pos),
            'path': [list(p) for p in self.path],
            'grid_types': [[cell['type'] for cell in row] for row in self.grid],
            'difficulty': self.difficulty
        }
        try:
            with open(filename, 'w') as f:
                json.dump(data, f)
            self.message = f"MAP SAVED // {filename}"
        except Exception as e:
            self.message = f"SAVE FAILED // {e}"
    
    def load_map(self, filename="saved_map.json"):
        filename = self._save_path(filename)
        # Load a saved map layout from file
        if not os.path.exists(filename):
            self.message = f"LOAD FAILED // {filename} not found"
            return
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
            
            self.start_pos = tuple(data['start_pos'])
            self.end_pos = tuple(data['end_pos'])
            self.path = [tuple(p) for p in data['path']]
            
            # Rebuild grid
            self.grid = []
            for y in range(GRID_HEIGHT):
                row = []
                for x in range(GRID_WIDTH):
                    # Legacy saves may contain 'wall' borders - now open space
                    ctype = data['grid_types'][y][x]
                    if ctype == 'wall':
                        ctype = 'empty'
                    row.append({'type': ctype, 'tower': None})
                self.grid.append(row)
            
            if 'difficulty' in data:
                self.difficulty = data['difficulty']
            
            self.message = f"MAP LOADED // {filename}"
        except Exception as e:
            self.message = f"LOAD FAILED // {e}"
    
    def draw_background(self):
        # Deep space gradient
        self.screen.fill((3, 3, 15))
        
        t = pygame.time.get_ticks() / 1000.0
        
        # Draw nebula clouds (drifting softly)
        neb_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        for neb in self.nebulas:
            nx = neb['x'] + math.sin(t * neb['drift']) * 40
            ny = neb['y'] + math.cos(t * neb['drift'] * 0.7) * 25
            for r in range(neb['radius'], 0, -20):
                alpha = int(30 * (1 - r / neb['radius']))
                pygame.draw.circle(neb_surface, (*neb['color'], alpha),
                                   (int(nx), int(ny)), r)
        self.screen.blit(neb_surface, (0, 0))
        
        # Draw twinkling stars
        for star in self.stars:
            brightness = int(170 + 85 * math.sin(t * star['speed'] + star['phase']))
            brightness = max(80, min(255, brightness))
            tint = star.get('tint')
            if tint:
                color = (min(255, brightness * tint[0] // 255),
                         min(255, brightness * tint[1] // 255),
                         min(255, brightness * tint[2] // 255))
            else:
                color = (brightness, brightness, min(255, brightness + 40))
            pygame.draw.circle(self.screen, color,
                               (int(star['x']), int(star['y'])), star['size'])
        
        # Occasional shooting star streak
        for i in range(2):
            streak_x = (t * 300 + i * 700) % (GRID_WIDTH * CELL_SIZE + 300) - 150
            streak_y = 50 + i * 200 + math.sin(t + i) * 60
            if 0 < streak_x < GRID_WIDTH * CELL_SIZE:
                pygame.draw.line(self.screen, (180, 200, 255),
                                 (int(streak_x), int(streak_y)),
                                 (int(streak_x - 40), int(streak_y + 10)), 2)
    
    def draw_grid(self):
        for y in range(GRID_HEIGHT):
            for x in range(GRID_WIDTH):
                cell = self.grid[y][x]
                px = x * CELL_SIZE
                py = y * CELL_SIZE
                
                if cell['type'] == 'path':
                    # Check if this is start or end
                    if (x, y) == self.start_pos:
                        # Start - neon blue with glow
                        pygame.draw.rect(self.screen, DARK_CYAN, (px, py, CELL_SIZE, CELL_SIZE))
                        pygame.draw.rect(self.screen, NEON_BLUE, (px, py, CELL_SIZE, CELL_SIZE), 3)
                        
                        # Draw "S" for start
                        font = pygame.font.Font(None, 48)
                        text = font.render("S", True, WHITE)
                        text_rect = text.get_rect(center=(px + CELL_SIZE // 2, py + CELL_SIZE // 2))
                        self.screen.blit(text, text_rect)
                    elif (x, y) == self.end_pos:
                        # End - neon red with glow
                        pygame.draw.rect(self.screen, (40, 10, 20), (px, py, CELL_SIZE, CELL_SIZE))
                        pygame.draw.rect(self.screen, NEON_RED, (px, py, CELL_SIZE, CELL_SIZE), 3)
                        
                        # Draw "E" for end
                        font = pygame.font.Font(None, 48)
                        text = font.render("E", True, WHITE)
                        text_rect = text.get_rect(center=(px + CELL_SIZE // 2, py + CELL_SIZE // 2))
                        self.screen.blit(text, text_rect)
                    else:
                        # Regular path - translucent tint over the starfield + circuit pattern
                        self.screen.blit(self.path_cell_overlay, (px, py))
                        pygame.draw.rect(self.screen, GRID_COLOR, (px, py, CELL_SIZE, CELL_SIZE), 1)
                        # Add circuit-like pattern
                        pygame.draw.line(self.screen, GRID_COLOR, (px + CELL_SIZE // 2, py), (px + CELL_SIZE // 2, py + CELL_SIZE), 1)
                        pygame.draw.line(self.screen, GRID_COLOR, (px, py + CELL_SIZE // 2), (px + CELL_SIZE, py + CELL_SIZE // 2), 1)
                else:
                    # Empty cell - translucent tint so stars show through, subtle grid
                    self.screen.blit(self.empty_cell_overlay, (px, py))
                    pygame.draw.rect(self.screen, (15, 15, 25), (px, py, CELL_SIZE, CELL_SIZE), 1)
    
    def draw_ui(self):
        ui_x = GRID_WIDTH * CELL_SIZE
        ui_width = SCREEN_WIDTH - ui_x
        
        # Draw UI background - cyberpunk dark panel
        pygame.draw.rect(self.screen, DARK_GRAY, (ui_x, 0, ui_width, SCREEN_HEIGHT))
        pygame.draw.rect(self.screen, NEON_CYAN, (ui_x, 0, ui_width, SCREEN_HEIGHT), 3)
        # Add scanline effect
        for i in range(0, SCREEN_HEIGHT, 4):
            pygame.draw.line(self.screen, (0, 40, 50, 30), (ui_x, i), (ui_x + ui_width, i), 1)
        
        # Draw stats with neon style
        y_offset = 30
        stats = [
            f"Wave: {self.wave}",
            f"Lives: {self.lives}",
            f"Credits: {self.credits}",
            f"Enemies: {len(self.enemies)}"
        ]
        
        for stat in stats:
            # Neon glow effect
            text = self.font.render(stat, True, NEON_CYAN)
            self.screen.blit(text, (ui_x + 35, y_offset))
            y_offset += 32
        
        # Player name + personal best (click to edit name)
        best = self.high_scores.get(self.player_name, 0)
        if self.editing_name:
            pygame.draw.rect(self.screen, (35, 20, 55), (ui_x + 28, y_offset - 3, ui_width - 56, 36))
            pygame.draw.rect(self.screen, NEON_PINK, (ui_x + 28, y_offset - 3, ui_width - 56, 36), 2)
            name_text = f"NAME: {self.player_name}_"
            name_color = NEON_PINK
        else:
            name_text = f"{self.player_name} | BEST: W{best}"
            name_color = NEON_GREEN
        text = self.font.render(name_text, True, name_color)
        self.screen.blit(text, (ui_x + 35, y_offset))
        y_offset += 32
        
        y_offset += 10
        
        # Difficulty selector - 4 buttons in a row
        text = self.font.render("DIFFICULTY", True, NEON_PURPLE)
        self.screen.blit(text, (ui_x + 30, y_offset))
        y_offset += 40
        
        btn_width = (ui_width - 60 - 15) // 4
        diff_keys = list(DIFFICULTIES.keys())
        for i, key in enumerate(diff_keys):
            d = DIFFICULTIES[key]
            bx = ui_x + 30 + i * (btn_width + 5)
            active = self.difficulty == key
            btn_color = d['color'] if active else (40, 40, 55)
            pygame.draw.rect(self.screen, btn_color, (bx, y_offset, btn_width, 35))
            pygame.draw.rect(self.screen, NEON_CYAN if active else (70, 70, 90),
                             (bx, y_offset, btn_width, 35), 2)
            text = self.font.render(d['name'][:4], True,
                                    BLACK if active else WHITE)
            text_rect = text.get_rect(center=(bx + btn_width // 2, y_offset + 17))
            self.screen.blit(text, text_rect)
        
        y_offset += 45
        
        # Path length + game speed controls on one row
        text = self.font.render("LEN", True, NEON_PURPLE)
        self.screen.blit(text, (ui_x + 30, y_offset + 5))
        
        minus_bx = ui_x + 88
        plus_bx = ui_x + 165
        pct_cx = ui_x + 141
        # Minus button
        pygame.draw.rect(self.screen, NEON_BLUE, (minus_bx, y_offset, 28, 32))
        pygame.draw.rect(self.screen, NEON_CYAN, (minus_bx, y_offset, 28, 32), 2)
        text = self.font.render("-", True, BLACK)
        text_rect = text.get_rect(center=(minus_bx + 14, y_offset + 16))
        self.screen.blit(text, text_rect)
        # Percentage display (small font so it clears the buttons)
        text = self.small_font.render(f"{self.min_path_pct}%", True, NEON_GREEN)
        text_rect = text.get_rect(center=(pct_cx, y_offset + 16))
        self.screen.blit(text, text_rect)
        # Plus button
        pygame.draw.rect(self.screen, NEON_BLUE, (plus_bx, y_offset, 28, 32))
        pygame.draw.rect(self.screen, NEON_CYAN, (plus_bx, y_offset, 28, 32), 2)
        text = self.font.render("+", True, BLACK)
        text_rect = text.get_rect(center=(plus_bx + 14, y_offset + 16))
        self.screen.blit(text, text_rect)
        
        # Speed cycle button: SPD: Nx
        spd_bx = ui_x + 210
        pygame.draw.rect(self.screen, NEON_BLUE, (spd_bx, y_offset, 130, 32))
        pygame.draw.rect(self.screen, NEON_CYAN, (spd_bx, y_offset, 130, 32), 3)
        text = self.font.render(f"SPD: {self.game_speed}x", True, BLACK)
        text_rect = text.get_rect(center=(spd_bx + 65, y_offset + 16))
        self.screen.blit(text, text_rect)
        
        y_offset += 50
        
        # Draw tower buttons with cyberpunk style - 2-column grid
        btn_w = (ui_width - 60 - 10) // 2
        btn_h = 40
        mx, my = pygame.mouse.get_pos()
        self.hover_tower_type = None
        for i, (tower_type, config) in enumerate(TOWER_TYPES.items()):
            color = config['color']
            cost = config['cost']
            can_afford = self.credits >= cost
            col = i % 2
            row = i // 2
            bx = ui_x + 30 + col * (btn_w + 10)
            by = y_offset + row * (btn_h + 6)
            
            if bx <= mx <= bx + btn_w and by <= my <= by + btn_h:
                self.hover_tower_type = tower_type
            
            # Cyberpunk button style
            if not can_afford:
                button_color = GRAY
                border_color = GRAY
            elif self.selected_tower_type == tower_type:
                button_color = color
                border_color = WHITE
            else:
                button_color = (color[0] // 2, color[1] // 2, color[2] // 2)  # Dimmed version
                border_color = color
            
            pygame.draw.rect(self.screen, button_color, (bx, by, btn_w, btn_h))
            pygame.draw.rect(self.screen, border_color, (bx, by, btn_w, btn_h), 3)
            
            # Tech corners
            pygame.draw.line(self.screen, border_color, (bx, by + 8), (bx + 8, by), 2)
            pygame.draw.line(self.screen, border_color, (bx, by + 8), (bx, by), 2)
            pygame.draw.line(self.screen, border_color, (bx + btn_w, by + 8), (bx + btn_w - 8, by), 2)
            pygame.draw.line(self.screen, border_color, (bx + btn_w, by + 8), (bx + btn_w, by), 2)
            
            text = self.small_font.render(f"{config['name'].replace(' Bot', '')} {cost}c", True, WHITE)
            text_rect = text.get_rect(center=(bx + btn_w // 2, by + btn_h // 2))
            self.screen.blit(text, text_rect)
        
        y_offset += ((len(TOWER_TYPES) + 1) // 2) * (btn_h + 6) + 20
        
        # Draw action buttons with cyberpunk style
        # Start Wave button
        wave_color = NEON_GREEN if not self.wave_in_progress else GRAY
        pygame.draw.rect(self.screen, wave_color, (ui_x + 30, y_offset, (ui_width - 60) // 2 - 10, 50))
        pygame.draw.rect(self.screen, NEON_CYAN, (ui_x + 30, y_offset, (ui_width - 60) // 2 - 10, 50), 3)
        text = self.small_font.render("START WAVE", True, BLACK)
        text_rect = text.get_rect(center=(ui_x + 30 + (ui_width - 60) // 4 - 5, y_offset + 25))
        self.screen.blit(text, text_rect)
        
        # Upgrade button - shows cost when a tower is selected
        upgrade_color = NEON_PURPLE if self.selected_tower else GRAY
        pygame.draw.rect(self.screen, upgrade_color, (ui_x + ui_width // 2 + 5, y_offset, (ui_width - 60) // 2 - 10, 50))
        pygame.draw.rect(self.screen, NEON_CYAN, (ui_x + ui_width // 2 + 5, y_offset, (ui_width - 60) // 2 - 10, 50), 3)
        upg_label = "UPGRADE"
        if self.selected_tower:
            upg_label = f"UPG {self.selected_tower.get_upgrade_cost()}c"
        text = self.small_font.render(upg_label, True, BLACK)
        text_rect = text.get_rect(center=(ui_x + ui_width // 2 + 5 + (ui_width - 60) // 4 - 5, y_offset + 25))
        self.screen.blit(text, text_rect)
        
        # Sell button (second action row)
        sell_y = y_offset + 55
        sell_color = NEON_ORANGE if self.selected_tower else GRAY
        pygame.draw.rect(self.screen, sell_color, (ui_x + 30, sell_y, ui_width - 60, 45))
        pygame.draw.rect(self.screen, NEON_CYAN, (ui_x + 30, sell_y, ui_width - 60, 45), 3)
        sell_label = "SELL"
        if self.selected_tower:
            sell_label = f"SELL (+{self.selected_tower.get_sell_value()}c)"
        text = self.small_font.render(sell_label, True, BLACK)
        text_rect = text.get_rect(center=(ui_x + ui_width // 2, sell_y + 22))
        self.screen.blit(text, text_rect)
        
        # Save/Load/Regen buttons (third action row)
        sl_y = sell_y + 50
        third_w = (ui_width - 80) // 3
        labels = ["SAVE", "LOAD", "RESET"]
        for i, label in enumerate(labels):
            bx = ui_x + 30 + i * (third_w + 10)
            pygame.draw.rect(self.screen, NEON_BLUE, (bx, sl_y, third_w, 40))
            pygame.draw.rect(self.screen, NEON_CYAN, (bx, sl_y, third_w, 40), 3)
            text = self.small_font.render(label, True, BLACK)
            text_rect = text.get_rect(center=(bx + third_w // 2, sl_y + 20))
            self.screen.blit(text, text_rect)
        
        y_offset += 145
        
        # Show selected tower level + ability status
        if self.selected_tower:
            ability = self.selected_tower.get_ability_status()
            info = f"LV{self.selected_tower.level} {self.selected_tower.config['name']}"
            if ability:
                info += f" | {ability}"
        else:
            info = "Click a placed tower"
        text = self.small_font.render(info, True, NEON_PINK)
        self.screen.blit(text, (ui_x + 30, y_offset))
        
        y_offset += 34
        
        # Draw instructions
        instructions = [
            "Select robot, click empty cell",
            "Click tower to upgrade/sell",
            "S = Start, E = End (path)",
            "Click NAME stat to set pilot"
        ]
        
        for instruction in instructions:
            text = self.small_font.render(instruction, True, WHITE)
            self.screen.blit(text, (ui_x + 30, y_offset))
            y_offset += 24
        
        y_offset += 12
        
        # Draw message with neon effect (word-wrapped to fit panel)
        wrapped = []
        for line in self.message.split('\n'):
            wrapped.extend(textwrap.wrap(line, 38) or [""])
        for line in wrapped:
            text = self.small_font.render(line, True, NEON_ORANGE)
            self.screen.blit(text, (ui_x + 30, y_offset))
            y_offset += 24
        
        # Info panels: selected tower upgrade stats, else shop button info
        if self.selected_tower:
            self.draw_selected_tower_info()
        else:
            info_type = self.hover_tower_type or self.selected_tower_type
            if info_type:
                self.draw_tower_info(info_type)
    
    def draw_selected_tower_info(self):
        # Stats of the selected tower + what the next upgrade gives
        tw = self.selected_tower
        config = tw.config
        f = self.small_font
        next_dmg = int(tw.damage * 1.5)
        next_rng = int(tw.range * 1.1)
        next_rate = max(60, int(tw.fire_rate * 0.9))
        if config.get('ability') == 'continuous' and tw.level + 1 in (3, 5):
            next_rate = int(next_rate * (0.6 if tw.level + 1 == 3 else 0.5))
        
        lines = [
            f"{config['name']}  LV{tw.level}",
            f"DMG {tw.damage} | RNG {tw.range} | RATE {tw.fire_rate}ms",
            f"NEXT LV{tw.level + 1}: {next_dmg}dmg {next_rng}rng {next_rate}ms",
        ]
        ability = tw.get_ability_status()
        if tw.level + 1 in (3, 5) and config.get('ability_name'):
            lines.append(f"LV{tw.level + 1} UNLOCKS {config['ability_name']}!")
        elif ability:
            lines.append(f"ACTIVE: {ability}")
        effect = config.get('effect')
        if effect:
            if effect['type'] == 'slow':
                lines.append(f"SLOWS {int((1 - effect['factor']) * 100)}%")
            elif effect['type'] == 'poison':
                lines.append("POISONS targets")
            elif effect['type'] == 'pull':
                lines.append("YANKS foes back")
        lines.append(f"UPG {tw.get_upgrade_cost()}c | SELL +{tw.get_sell_value()}c")
        
        box_w = 395
        box_h = len(lines) * 25 + 14
        bx, by = 10, SCREEN_HEIGHT - box_h - 10
        s = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        s.fill((5, 10, 30, 220))
        self.screen.blit(s, (bx, by))
        pygame.draw.rect(self.screen, config['color'], (bx, by, box_w, box_h), 2)
        yy = by + 7
        for line in lines:
            if 'UNLOCKS' in line or line.startswith('NEXT'):
                col = NEON_GREEN
            elif line.startswith(('ACTIVE', 'SLOWS', 'POISONS', 'YANKS')):
                col = NEON_CYAN
            elif line.startswith('UPG'):
                col = NEON_ORANGE
            else:
                col = WHITE
            self.screen.blit(f.render(line, True, col), (bx + 10, yy))
            yy += 25
    
    def draw_tower_info(self, tower_type):
        config = TOWER_TYPES[tower_type]
        f = self.small_font
        lines = [
            f"{config['name']} - {config['cost']}c",
            f"DMG {config['damage']} | RNG {config['range']} | RATE {config['fire_rate']}ms",
        ]
        effect = config.get('effect')
        if effect:
            if effect['type'] == 'slow':
                lines.append(f"SLOW: {int((1 - effect['factor']) * 100)}% for {effect['duration'] // 1000}s")
            elif effect['type'] == 'poison':
                lines.append(f"POISON: {effect['dps']}/s for {effect['duration'] // 1000}s")
        if config.get('ability'):
            lines.append(f"UPG: {config['ability_name']} (lvl3+)")
        lines.append(f"+ {config.get('pros', '')}")
        lines.append(f"- {config.get('cons', '')}")
        
        box_w = 370
        box_h = len(lines) * 25 + 14
        bx, by = 10, SCREEN_HEIGHT - box_h - 10
        s = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        s.fill((5, 10, 30, 220))
        self.screen.blit(s, (bx, by))
        pygame.draw.rect(self.screen, config['color'], (bx, by, box_w, box_h), 2)
        yy = by + 7
        for line in lines:
            if line.startswith('+'):
                col = NEON_GREEN
            elif line.startswith('-'):
                col = NEON_RED
            elif line.startswith(('SLOW', 'POISON', 'UPG')):
                col = NEON_CYAN
            else:
                col = WHITE
            self.screen.blit(f.render(line, True, col), (bx + 10, yy))
            yy += 25
    
    def handle_click(self, pos):
        # Get the actual mouse position relative to the window
        x, y = pygame.mouse.get_pos()
        ui_x = GRID_WIDTH * CELL_SIZE
        ui_width = SCREEN_WIDTH - ui_x
        
        # Name prompt is modal: while open, taps only hit the on-screen keys
        if self.editing_name:
            for rect, ch in getattr(self, '_name_keys', []):
                if rect.collidepoint(x, y):
                    if ch == 'DEL':
                        self.player_name = self.player_name[:-1]
                    elif ch == 'OK':
                        self.editing_name = False
                        if not self.player_name:
                            self.player_name = "PLAYER"
                        self.message = f"PILOT ID SET: {self.player_name}"
                    elif len(self.player_name) < 10:
                        self.player_name += ch
                    return
            return
        
        # Click the name stat (drawn at y=158) to edit; clicking elsewhere ends editing
        in_name_box = 155 <= y <= 195 and ui_x + 28 <= x <= ui_x + ui_width - 28
        self.editing_name = in_name_box
        if in_name_box:
            self.message = "Type pilot name, ENTER to confirm"
            return
        
        # Check if click is in game area
        if x < GRID_WIDTH * CELL_SIZE:
            grid_x = x // CELL_SIZE
            grid_y = y // CELL_SIZE
            
            if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT:
                cell = self.grid[grid_y][grid_x]
                
                # Place tower
                if self.selected_tower_type and cell['type'] == 'empty' and not cell['tower']:
                    config = TOWER_TYPES[self.selected_tower_type]
                    cost = config['cost']
                    if self.credits >= cost:
                        self.credits -= cost
                        tower = Tower(grid_x, grid_y, self.selected_tower_type)
                        self.towers.append(tower)
                        cell['tower'] = tower
                        self.message = f"{config['name']} placed! (-{cost}c)"
                    else:
                        self.message = f"Not enough credits! Need {cost}c, have {self.credits}c"
                # Select existing tower
                elif cell['tower']:
                    self.selected_tower = cell['tower']
                    self.selected_tower_type = None
                    self.message = "Tower selected"
                # Deselect
                else:
                    self.selected_tower = None
                    self.selected_tower_type = None
                    self.message = ""
        
        # Check if click is in UI area
        else:
            ui_x = GRID_WIDTH * CELL_SIZE
            ui_width = SCREEN_WIDTH - ui_x
            
            # Check difficulty buttons (drawn at y=240, height 35)
            btn_width = (ui_width - 60 - 15) // 4
            diff_keys = list(DIFFICULTIES.keys())
            for i, key in enumerate(diff_keys):
                bx = ui_x + 30 + i * (btn_width + 5)
                if bx <= x <= bx + btn_width and 240 <= y <= 275:
                    if self.difficulty != key and not self.wave_in_progress:
                        self.difficulty = key
                        diff = DIFFICULTIES[key]
                        # Apply new starting resources if still on wave 1
                        if self.wave == 1 and len(self.towers) == 0:
                            self.credits = diff['credits']
                            self.lives = diff['lives']
                        self.message = f"DIFFICULTY SET // {diff['name']}"
                    elif self.wave_in_progress:
                        self.message = "Cannot change difficulty mid-wave!"
                    return
            
            # Check path length +/- and speed buttons (drawn at y=285, height 32)
            if 285 <= y <= 317:
                if ui_x + 88 <= x <= ui_x + 116:  # path len minus
                    if self.min_path_pct > 15:
                        self.min_path_pct -= 5
                        self.message = f"PATH LENGTH: {self.min_path_pct}%"
                    return
                if ui_x + 165 <= x <= ui_x + 193:  # path len plus
                    if self.min_path_pct < 55:
                        self.min_path_pct += 5
                        self.message = f"PATH LENGTH: {self.min_path_pct}%"
                    return
                if ui_x + 210 <= x <= ui_x + 340:  # speed cycle
                    self.game_speed = self.game_speed % 3 + 1  # 1 -> 2 -> 3 -> 1
                    self.message = f"SPEED: {self.game_speed}x"
                    return
            
            # Check tower buttons (2-col grid at y=335, 40px tall, 46px pitch)
            tbtn_w = (ui_width - 60 - 10) // 2
            for i, tower_type in enumerate(TOWER_TYPES.keys()):
                col = i % 2
                row = i // 2
                tbx = ui_x + 30 + col * (tbtn_w + 10)
                tby = 335 + row * 46
                if tbx <= x <= tbx + tbtn_w and tby <= y <= tby + 40:
                    if self.selected_tower_type == tower_type:
                        self.selected_tower_type = None
                    else:
                        self.selected_tower_type = tower_type
                        self.selected_tower = None
                    return
            
            # Check start wave button
            # Tower grid: 335 + 4*46 + 20 = 539
            action_y_offset = 539
            button_y_start = action_y_offset
            button_y_end = action_y_offset + 50
            if ui_x + 30 <= x <= ui_x + (ui_width - 60) // 2 + 20 and button_y_start <= y <= button_y_end:
                self.start_wave()
                return
            
            # Check upgrade button
            if ui_x + ui_width // 2 + 5 <= x <= ui_x + ui_width - 30 and button_y_start <= y <= button_y_end:
                if self.selected_tower:
                    cost = self.selected_tower.get_upgrade_cost()
                    if self.credits >= cost:
                        self.credits -= cost
                        self.selected_tower.upgrade()
                        ability = self.selected_tower.get_ability_status()
                        if ability and self.selected_tower.level in (3, 5):
                            self.message = f"{self.selected_tower.config['ability_name']} UNLOCKED! (-{cost}c)"
                        else:
                            self.message = f"Tower upgraded! (-{cost}c)"
                    else:
                        self.message = f"Not enough credits! Need {cost}c, have {self.credits}c"
                else:
                    self.message = "Select a tower first!"
                return
            
            # Check sell button (below action row, height 45)
            sell_y_start = action_y_offset + 55
            sell_y_end = sell_y_start + 45
            if ui_x + 30 <= x <= ui_x + ui_width - 30 and sell_y_start <= y <= sell_y_end:
                if self.selected_tower:
                    tower = self.selected_tower
                    refund = tower.get_sell_value()
                    self.credits += refund
                    self.towers.remove(tower)
                    self.grid[tower.grid_y][tower.grid_x]['tower'] = None
                    self.selected_tower = None
                    self.message = f"Tower sold! (+{refund}c)"
                else:
                    self.message = "Select a tower first!"
                return
            
            # Check save/load/regen buttons (third row: sell_y + 50, height 40)
            sl_y_start = sell_y_start + 50
            sl_y_end = sl_y_start + 40
            third_w = (ui_width - 80) // 3
            if sl_y_start <= y <= sl_y_end:
                for i in range(3):
                    bx = ui_x + 30 + i * (third_w + 10)
                    if bx <= x <= bx + third_w:
                        if i == 0:
                            self.save_map()
                        elif i == 1:
                            self.load_map()
                        else:
                            self.reset_game()
                        return
    
    def update(self):
        if self.game_over:
            if self.new_record:
                self.message = f"GAME OVER! Press R to restart.\nNEW RECORD: W{self.new_record}!"
            else:
                best = self.high_scores.get(self.player_name, 0)
                self.message = f"GAME OVER! Press R to restart.\n{self.player_name} BEST: W{best}"
            return
        
        # Drift stars across the sky (wrap around)
        for star in self.stars:
            star['x'] += star['vx']
            star['y'] += star['vy']
            if star['x'] < 0:
                star['x'] += GRID_WIDTH * CELL_SIZE
            elif star['x'] > GRID_WIDTH * CELL_SIZE:
                star['x'] -= GRID_WIDTH * CELL_SIZE
            if star['y'] < 0:
                star['y'] += SCREEN_HEIGHT
            elif star['y'] > SCREEN_HEIGHT:
                star['y'] -= SCREEN_HEIGHT
        
        # Spawn enemies
        self.spawn_enemies()
        
        # Update enemies
        for enemy in self.enemies[:]:
            result = enemy.update()
            if result == 'reached_end':
                self.lives -= 1
                self.enemies.remove(enemy)
                if self.lives <= 0:
                    self.game_over = True
                    self.record_score()
        
        # Update towers
        current_time = pygame.time.get_ticks()
        for tower in self.towers:
            if tower.can_fire(current_time):
                # Find up to N closest enemies in range (multishot/chain)
                num_targets = tower.get_num_targets()
                in_range = []
                for enemy in self.enemies:
                    dx = enemy.x - tower.x
                    dy = enemy.y - tower.y
                    distance = math.sqrt(dx * dx + dy * dy)
                    if distance <= tower.range:
                        in_range.append((distance, enemy))
                
                if in_range:
                    in_range.sort(key=lambda t: t[0])
                    targets = [e for _, e in in_range[:num_targets]]
                    for target in targets:
                        self.projectiles.append(tower.fire(target))
        
        # Update projectiles
        for projectile in self.projectiles[:]:
            projectile.update()
            if not projectile.active:
                # Apply AOE splash around the hit point
                if projectile.hit and projectile.aoe_radius > 0:
                    for enemy in self.enemies:
                        if enemy is projectile.target:
                            continue
                        dx = enemy.x - projectile.hit_x
                        dy = enemy.y - projectile.hit_y
                        if math.sqrt(dx * dx + dy * dy) <= projectile.aoe_radius:
                            enemy.take_damage(projectile.damage)
                            enemy.apply_effect(projectile.effect)
                    # Spawn explosion ring effect
                    self.effects.append({
                        'x': projectile.hit_x, 'y': projectile.hit_y,
                        'max_r': projectile.aoe_radius, 't': 0,
                        'color': projectile.color
                    })
                self.projectiles.remove(projectile)
        
        # Update effects (expanding explosion rings)
        for fx in self.effects[:]:
            fx['t'] += 1
            if fx['t'] > 12:
                self.effects.remove(fx)
        
        # Collect rewards from dead enemies and remove them
        for enemy in self.enemies:
            if not enemy.active:
                self.credits += enemy.reward
        self.enemies = [e for e in self.enemies if e.active]
        
        # Check wave completion
        self.check_wave_complete()
    
    def draw(self):
        self.draw_background()
        
        self.draw_grid()
        
        # Draw towers
        for tower in self.towers:
            tower.draw(self.screen, tower == self.selected_tower)
        
        # Draw enemies
        for enemy in self.enemies:
            enemy.draw(self.screen)
        
        # Draw projectiles
        for projectile in self.projectiles:
            projectile.draw(self.screen)
        
        # Draw AOE explosion rings
        for fx in self.effects:
            progress = fx['t'] / 12.0
            radius = int(fx['max_r'] * progress)
            alpha = int(200 * (1 - progress))
            if radius > 0:
                fx_surf = pygame.Surface((radius * 2 + 4, radius * 2 + 4), pygame.SRCALPHA)
                pygame.draw.circle(fx_surf, (*fx['color'], alpha),
                                   (radius + 2, radius + 2), radius, 3)
                self.screen.blit(fx_surf, (fx['x'] - radius - 2, fx['y'] - radius - 2))
        
        # Draw placement preview
        if self.selected_tower_type:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if mouse_x < GRID_WIDTH * CELL_SIZE:
                grid_x = mouse_x // CELL_SIZE
                grid_y = mouse_y // CELL_SIZE
                
                if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT:
                    config = TOWER_TYPES[self.selected_tower_type]
                    px = grid_x * CELL_SIZE
                    py = grid_y * CELL_SIZE
                    cx = px + CELL_SIZE // 2
                    cy = py + CELL_SIZE // 2
                    
                    # Range circle - shows the tower's coverage at this spot
                    rng = config['range']
                    range_surf = pygame.Surface((rng * 2, rng * 2), pygame.SRCALPHA)
                    pygame.draw.circle(range_surf, (*config['color'], 35), (rng, rng), rng)
                    pygame.draw.circle(range_surf, (*config['color'], 160), (rng, rng), rng, 2)
                    self.screen.blit(range_surf, (cx - rng, cy - rng))
                    
                    # Draw cyberpunk-style preview (red if cell not placeable)
                    placeable = (self.grid[grid_y][grid_x]['type'] == 'empty'
                                 and not self.grid[grid_y][grid_x]['tower'])
                    pcol = config['color'] if placeable else NEON_RED
                    s = pygame.Surface((CELL_SIZE, CELL_SIZE), pygame.SRCALPHA)
                    pygame.draw.rect(s, (*pcol, 100), (5, 5, CELL_SIZE - 10, CELL_SIZE - 10))
                    pygame.draw.rect(s, (*pcol, 200), (5, 5, CELL_SIZE - 10, CELL_SIZE - 10), 2)
                    # Tech corners
                    pygame.draw.line(s, (*pcol, 200), (5, 15), (15, 5), 2)
                    pygame.draw.line(s, (*pcol, 200), (CELL_SIZE - 5, 15), (CELL_SIZE - 15, 5), 2)
                    self.screen.blit(s, (px, py))
        
        self.draw_ui()
        
        # Name entry prompt overlays everything while active
        if self.editing_name:
            self.draw_name_prompt()
        
        pygame.display.flip()
    
    NAME_KEY_ROWS = ["1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"]

    def draw_name_prompt(self):
        box_w, box_h = 560, 400
        bx = (GRID_WIDTH * CELL_SIZE - box_w) // 2
        by = (SCREEN_HEIGHT - box_h) // 2
        # Dim the play field behind the prompt
        dim = pygame.Surface((GRID_WIDTH * CELL_SIZE, SCREEN_HEIGHT), pygame.SRCALPHA)
        dim.fill((0, 0, 10, 140))
        self.screen.blit(dim, (0, 0))
        # Prompt box
        s = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        s.fill((8, 12, 35, 235))
        self.screen.blit(s, (bx, by))
        pygame.draw.rect(self.screen, NEON_CYAN, (bx, by, box_w, box_h), 3)
        title = self.font.render("ENTER PILOT NAME", True, NEON_CYAN)
        self.screen.blit(title, title.get_rect(center=(bx + box_w // 2, by + 28)))
        # Input field
        field = (bx + 50, by + 52, box_w - 100, 42)
        pygame.draw.rect(self.screen, (15, 25, 55), field)
        pygame.draw.rect(self.screen, NEON_PINK, field, 2)
        cursor = "_" if (pygame.time.get_ticks() // 500) % 2 == 0 else " "
        name_text = self.font.render(self.player_name + cursor, True, NEON_GREEN)
        self.screen.blit(name_text, name_text.get_rect(center=(bx + box_w // 2, by + 73)))
        
        # On-screen keyboard (tappable; hardware keys also work)
        key, gap = 42, 6
        ky = by + 108
        self._name_keys = []
        for row in self.NAME_KEY_ROWS:
            row_w = len(row) * key + (len(row) - 1) * gap
            kx = bx + (box_w - row_w) // 2
            for ch in row:
                rect = pygame.Rect(kx, ky, key, key)
                self._name_keys.append((rect, ch))
                pygame.draw.rect(self.screen, (25, 40, 80), rect)
                pygame.draw.rect(self.screen, NEON_CYAN, rect, 2)
                kt = self.font.render(ch, True, WHITE)
                self.screen.blit(kt, kt.get_rect(center=rect.center))
                kx += key + gap
            ky += key + gap
        # DEL and OK action keys
        ky += 6
        del_rect = pygame.Rect(bx + 50, ky, 150, 44)
        ok_rect = pygame.Rect(bx + box_w - 200, ky, 150, 44)
        self._name_keys += [(del_rect, 'DEL'), (ok_rect, 'OK')]
        pygame.draw.rect(self.screen, (60, 25, 45), del_rect)
        pygame.draw.rect(self.screen, NEON_RED, del_rect, 2)
        dt = self.font.render("DEL", True, WHITE)
        self.screen.blit(dt, dt.get_rect(center=del_rect.center))
        pygame.draw.rect(self.screen, (20, 55, 35), ok_rect)
        pygame.draw.rect(self.screen, NEON_GREEN, ok_rect, 2)
        ot = self.font.render("OK", True, WHITE)
        self.screen.blit(ot, ot.get_rect(center=ok_rect.center))
    
    def _frame(self):
        """One iteration of the main loop. Returns False to quit."""
        keep_running = True
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.record_score()
                keep_running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left click
                    self.handle_click(event.pos)
            elif event.type == pygame.KEYDOWN:
                if self.editing_name:
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        self.editing_name = False
                        if not self.player_name:
                            self.player_name = "PLAYER"
                        self.message = f"PILOT ID SET: {self.player_name}"
                    elif event.key in (pygame.K_ESCAPE, getattr(pygame, 'K_AC_BACK', -1)):
                        self.editing_name = False
                        if not self.player_name:
                            self.player_name = "PLAYER"
                    elif event.key == pygame.K_BACKSPACE:
                        self.player_name = self.player_name[:-1]
                    elif len(self.player_name) < 10 and event.unicode and (event.unicode.isalnum() or event.unicode in "-_"):
                        self.player_name += event.unicode.upper()
                elif event.key == pygame.K_r:
                    self.reset_game()
                elif event.key == getattr(pygame, 'K_AC_BACK', -2):
                    # Android hardware back button - save and exit
                    self.record_score()
                    keep_running = False

        for _ in range(self.game_speed):
            self.update()
        self.draw()
        self.clock.tick(FPS)
        return keep_running

    def run(self):
        while self._frame():
            pass
        pygame.quit()

    async def run_async(self):
        """Web driver: same loop but yields to the browser event loop
        each frame (required under pyodide/emscripten, where a blocking
        loop freezes the tab)."""
        import asyncio
        while self._frame():
            await asyncio.sleep(0)
        pygame.quit()

if __name__ == "__main__":
    game = Game()
    game.run()
