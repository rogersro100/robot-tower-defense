"""Entry point for Robot Tower Defense.

Works everywhere: desktop, Android (Buildozer/python-for-android
requires the entry point to be named main.py), and web via pygbag
(emscripten), which needs an asyncio-driven main loop.

No __name__ guard: this file is THE entry point - it is never imported
as a module, and some loaders (pygbag) execute it under a different
__name__, which would silently skip startup.
"""
import sys, traceback
print("RTD main.py: start", flush=True)
try:
    from tower_defense import Game
    print("RTD main.py: tower_defense imported", flush=True)
    _game = Game()
    print("RTD main.py: Game() constructed", flush=True)
    if sys.platform == 'emscripten':
        import asyncio
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(_game.run_async())
        else:
            # pygbag executes this file inside its own event loop -
            # asyncio.run() would fail, so schedule as a task instead.
            asyncio.ensure_future(_game.run_async())
        print("RTD main.py: run_async scheduled", flush=True)
    else:
        _game.run()
except Exception:
    traceback.print_exc()
    raise
