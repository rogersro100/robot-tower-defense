"""Entry point for Robot Tower Defense.

Works everywhere: desktop, Android (Buildozer/python-for-android
requires the entry point to be named main.py), and web via pygbag
(emscripten), which needs an asyncio-driven main loop.

No __name__ guard: this file is THE entry point - it is never imported
as a module, and some loaders (pygbag) execute it under a different
__name__, which would silently skip startup.
"""
import sys
from tower_defense import Game

if sys.platform == 'emscripten':
    import asyncio
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        asyncio.run(Game().run_async())
    else:
        # pygbag executes this file inside its own event loop -
        # asyncio.run() would fail, so schedule as a task instead.
        asyncio.ensure_future(Game().run_async())
else:
    Game().run()
