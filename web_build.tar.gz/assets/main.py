"""Entry point for Robot Tower Defense.

Works everywhere: desktop, Android (Buildozer/python-for-android
requires the entry point to be named main.py), and web via pygbag
(emscripten), which needs an asyncio-driven main loop.

No __name__ guard: this file is THE entry point - it is never imported
as a module, and some loaders (pygbag) execute it under a different
__name__, which would silently skip startup.
"""
import sys, traceback

if sys.platform == 'emscripten':
    import platform
    platform.window.RTD_MAIN_EXEC = True


def _log(msg):
    """Milestone log: JS console under emscripten (the on-page
    terminal is hidden), stdout elsewhere."""
    print("RTD " + msg, flush=True)
    if sys.platform == 'emscripten':
        try:
            import platform
            platform.window.console.log("RTD " + msg)
        except Exception:
            pass


_log("main.py: start")
try:
    from tower_defense import Game
    _log("main.py: tower_defense imported")
    _game = Game()
    _log("main.py: Game() constructed")
    if sys.platform == 'emscripten':
        import asyncio
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(_game.run_async())
        else:
            # pygbag executes this file inside its own event loop -
            # asyncio.run() would fail, so schedule as a task instead.
            asyncio.ensure_future(_game.run_async())
        _log("main.py: run_async scheduled")
    else:
        _game.run()
except Exception:
    traceback.print_exc()
    if sys.platform == 'emscripten':
        try:
            import platform
            platform.window.console.log("RTD FATAL - see terminal")
        except Exception:
            pass
    raise
